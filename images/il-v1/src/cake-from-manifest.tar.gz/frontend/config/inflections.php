<?php
/* $Id: inflections.php 29 2011-03-28 22:57:02Z richb $
   Instant Linux local exceptions
 */
$uninflected = array('.*meta', 'search');
?>
