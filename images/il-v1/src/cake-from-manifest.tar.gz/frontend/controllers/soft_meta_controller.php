<?php
// $Id: soft_meta_controller.php 233 2011-10-21 20:34:19Z richb $
// Created 7/2011 by richb

require_once 'libs/common.php';

class SoftMetaController extends AppController {
  var $helpers = array ('Html', 'Form', 'Javascript', 'Ajax');
  var $name = 'SoftMetas';
  var $view = 'Theme';

  function index() {
    parent::index();
  }

/////////////////////////////////////////////////////////////////////////////////////

  function view($id = null) {
    if (!$id && isset($this->params['named']['swmodule'])) {
      $this->_view_sw();
      $this->render("/soft_meta/view_sw");
    }
    else {
      parent::view($id);
    }
  }

  private function _view_sw() {
    $viewParams = $this->_getViewParams($this->params['named']);
    $scope = $this->currentUser['User']['scope_id'];

    $id = $viewParams['module_name'] . ':' . $viewParams['instance'];
    if (!empty($viewParams['host_id']))
      $id .= "({$viewParams['hostname']}-{$viewParams['host_id']})";
    else if (!empty($viewParams['set_name']))
      $id .= "({$viewParams['set_name']}-{$viewParams['resource_set_id']})";

    $this->data['workObject'] = $this->_softWorkObject($scope, $id, null, $viewParams);

    $this->{$this->modelClass}->query("CALL sw_meta_list(".
     $scope.",".
     (isset($viewParams['host_id']) ? $viewParams['host_id'] : 'NULL').",'".
     (isset($viewParams['set_name']) ? $viewParams['set_name'] : "''")."','".
     $viewParams['module_name']."','".
     $viewParams['instance']."');");
    $query = $this->{$this->modelClass}->query("SELECT * FROM tmp.sw_meta_list_result 
        JOIN meta_fields AS Opts ON Opts.id=sw_meta_list_result.meta_field_id
        ORDER BY sw_meta_list_result.function,display_seq,sw_meta_list_result.parameter_name;");
    $this->set('metaList',$query);
    $this->data['viewParams'] = $viewParams;

    // Pick up drop-down fields for OptLists
    $this->_getDropDown();
  }

/////////////////////////////////////////////////////////////////////////////////////

  function add() {
    parent::add();

    $this->set('enableAutocomplete', true);
  }

/////////////////////////////////////////////////////////////////////////////////////

  function edit($id = null) {
    if (!$id || !is_numeric($id)) {
      $id = str_replace('/soft_meta/edit/','',$_SERVER['REQUEST_URI']);
      $this->_edit_sw($id);
    }
    else {
      parent::edit($id);
      $this->data['dropDown']['meta_field_id'] = $this->SoftMeta->MetaField->find('list',
        array('fields' => array('MetaField.id', 'MetaField.parameter_name', 'MetaField.function'),
            'recursive' => -1,
            'conditions' => array(
	     'MetaField.table_name' => 'swmodules',
	     'MetaField.foreign_key' => $this->data['workObject']['Attrs']['swmodule_id']['data_value'],
	     'MetaField.scope_id' => $this->currentUser['User']['scope_id'])));
    }
    $this->set('enableAutocomplete', true);
  }

/////////////////////////////////////////////////////////////////////////////////////

  private function _edit_sw($id) {
    $scope = $this->currentUser['User']['scope_id'];

    $errset = false;
    if (!empty($this->data)) {
      $create_new = false;

      // Fetch old values (from cache)
      $cached = $this->_softWorkObject($scope, $id, null, null);
      if (empty($cached)) {
        $this->Session->setFlash(__('Object went away, could not edit', true));
        $errset = true;
      }
      $viewParams = $cached['viewParams'];
      if ($viewParams['instance'] == '_Create._') {
        $create_new = true;
        $viewParams['instance'] = $this->data['workObject']['Attrs']['instance']['data_value'];
      }
    }
    else {
      $viewParams = $this->_getViewParams($this->params['named']);
    }

    $this->set('viewParams',$viewParams);
    $relevant_meta = 'host_value_id';

    $id = $viewParams['module_name'] . ':' . $viewParams['instance'];

    // TBD how can it possibly be blank !?!?
    if ($viewParams['instance'] == '' || $viewParams['instance'] == 'Site.Default') {
      $relevant_meta = 'site_value_id';
      $viewParams['instance'] = '';
      $viewParams['resource_set_id'] = null;
    }
    else if (!empty($viewParams['host_id']))
      $id .= "({$viewParams['hostname']}-{$viewParams['host_id']})";
    else if (!empty($viewParams['set_name'])) {
      $id .= "({$viewParams['set_name']}-{$viewParams['resource_set_id']})";
      $relevant_meta = 'set_value_id';
    }

    if (!$errset && !empty($this->data)) {
      // This section taken from AppController::edit and modified to suit

      $this->{$this->modelClass}->useDbConfig = 'master';
      $this->{$this->modelClass}->Swmodule->History->useDbConfig = 'master';
      $this->{$this->modelClass}->currentUser = $this->currentUser;

      $history = array (
         'creator'     => $this->currentUser['User']['user_name'],
         'scope_id'    => $scope);

      switch ($relevant_meta) {
        case 'host_value_id':
	  $history['table_name']  = 'hosts';
	  $history['foreign_key'] = $viewParams['host_id'];
	  break;
	case 'resource_set_id':
	  $history['table_name']  = 'resource_sets';
	  $history['foreign_key'] = $viewParams['resource_set_id'];
	  break;
	default:
	  $history['table_name']  = 'swmodules';
	  $history['foreign_key'] = $viewParams['swmodule_id'];
      }

      $meta = array (
         'scope_id'    => $scope,
         'swmodule_id' => $viewParams['swmodule_id'],
         'instance'    => $viewParams['instance'],
	 'resource_set_id' => $viewParams['resource_set_id']);
      $this->data['History'] = array();
      $this->data[$this->modelClass] = array();
      $bool_model_loaded = false;

      $remove_ids = array();

      // Compare new and cached values for each field

      if (!$errset) {
        foreach ($cached['Attrs'] as $field => $oldattr) {
	    // Meta fields:
	    // If changed to default, delete from meta table
	    // If changed from default, add entry to $this->data['SoftMeta'] for saving

	    $defval = isset($oldattr['default_value']) ? $oldattr['default_value'] : '';
	    if ($oldattr['field_type_id'] == FTYPE_RESTRICTED || $oldattr['field_type_id'] == FTYPE_ARRAY_RESTRICTED)
	      $oldval = '';
	    else
	      $oldval = isset($oldattr['data_value']) ? $oldattr['data_value'] : $defval;
	    $newval = $this->data['workObject']['Attrs'][$field]['data_value'];
	    if ($newval != $oldval) {
	      if ($newval == $defval) {

	        // Default value selected: delete if present in meta table
	        if (isset ($oldattr[$relevant_meta]) && $oldattr[$relevant_meta] != '')
		  $remove_ids[] = $oldattr[$relevant_meta];
              }
	      else {

	        // Not default: add a meta entry to the stack for saving
	        if (isset($oldattr[$relevant_meta]) && $oldattr[$relevant_meta] != '')
		   $meta['id'] = $oldattr[$relevant_meta];
		else if (isset($meta['id']))
		  unset ($meta['id']);

		$meta['meta_field_id'] = $oldattr['meta_field_id'];
		if ($oldattr['field_type_id'] != FTYPE_BOOLEAN || !isset($oldattr['bool_style']))
		  $meta['data_value'] = $newval;
		else {
		  // True/false values come in varieties that are stored in
		  // the boolean_values table.  Use this table to look up the
		  // value to be stored.
		  
		  if (!$bool_model_loaded) {
		    $this->loadModel('BooleanValue');
		    $bool_model_loaded = true;
		  }
		  $query = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('bool_style' => $oldattr['bool_style']), 'recursive' => -1));
		  if (empty($query))
		    $meta['data_value'] = $newval;
		  else
		    $meta['data_value'] = $newval ? $query['BooleanValue']['true'] : $query['BooleanValue']['false'];
		}
		$this->data['SoftMeta'][] = $meta;

		// Also add it to the fields list for validation
		$this->data[$this->modelClass][$field] = $newval;
	      }

	      // Add a history entry
	      $history['field_name']     = $viewParams['module_name'].':'.$viewParams['instance'].':'.$field;
	      $history['previous_value'] = $oldval;
	      $history['new_value']      = $newval;
	      $history['field_type_id']  = $oldattr['field_type_id'];
	      $this->data['History'][] = $history;
            }
	    unset ($this->data[$this->modelClass][$field]);
	}

	// If creating a new instance, the first field on the form is
	// 'instance' so fill in the empty meta_field_id
	if ($create_new && empty($this->data['SoftMeta'][0]['meta_field_id'])) {
          $query = $this->{$this->modelClass}->MetaField->find('first',
            array('fields' => array('MetaField.id', 'MetaField.function'),
            'recursive' => -1,
            'conditions' => array(
	     'MetaField.table_name' => 'swmodules',
	     'MetaField.foreign_key' => $viewParams['swmodule_id'],
	     'MetaField.parameter_name' => '',
	     'MetaField.function' => MAIN_FUNCTION,
	     'MetaField.scope_id' => $this->currentUser['User']['scope_id'])));
	  if (isset($query['MetaField']['id'])) {
	    $meta['meta_field_id'] = $query['MetaField']['id'];
	    $meta['data_value'] = '';
	    $this->data['SoftMeta'][0] = $meta;
	  }
	  else
	    unset ($this->data['SoftMeta'][0]);
	}
        if (empty($this->data['SoftMeta']))
          unset($this->data['SoftMeta']);
      }

      // Null out or clean up certain fields
      //  TBD

      // Finally, time to save the data itself, including history
      if (!$errset) {
        if (isset($cached['validate']))
          $this->{$this->modelClass}->validate = $cached['validate'];
	  unset($this->data['workObject']);
	$this->{$this->modelClass}->set($this->data);
	if ($this->{$this->modelClass}->validates() && !empty($remove_ids)) {
//$this->log('deleting: '.print_r($remove_ids,true));
          if (!$this->{$this->modelClass}->deleteall(array(
	      $this->modelClass.'.scope_id' => $this->currentUser['User']['scope_id'],
	      $this->modelClass.'.id' => $remove_ids))) {
                    $this->Session->setFlash(__('Problem removing ',true).$this->modelClass.__(' entries', true));
                    $errset = true;
          }
	}
//$this->log('update: '.print_r($this->data, true));
        if (empty($this->data['SoftMeta']) || $this->{$this->modelClass}->saveall($this->data['SoftMeta'])) {
          if (!empty($this->data['History']))
	    $this->{$this->modelClass}->Swmodule->History->saveall($this->data['History']);
          $this->Session->setFlash($this->modelClass . ' '. __('entry updated', true));
	  $this->{$this->modelClass}->delWorkObject($this->currentUser['User']['scope_id'], $id);
          $this->redirect(array('controller' => 'hosts', 'action' => 'index'));
        }
        else {
          $this->Session->setFlash($this->modelClass.' ' . __('entry has errors', true). __(', fields: ', true) .
	      implode(", ", array_keys($this->{$this->modelClass}->invalidFields())));
	}
      }
      else {
        // Had error before scanning input, punt
        $this->redirect(array('controller' => 'hosts', 'action' => 'index'));
      }
    }

    $this->data['workObject'] = $this->_softWorkObject($scope, $id, null, $viewParams);

    // Populate the drop-down fields for foreign-key relationships
    $this->_getDropDown();
  }

/////////////////////////////////////////////////////////////////////////////////////

  function delete($id = null) {
// TBD this does not work
//    $auth = $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);
//    if (!$auth['Actions']['delete'])
//      $this->redirect(array('action' => 'index'));

    if ($id || !isset($this->params['named']['swmodule'])) {
      parent::delete($id);
    }
    else {
      $this->{$this->modelClass}->useDbConfig = 'master';
      $this->{$this->modelClass}->ResourceSet->History->useDbConfig = 'master';

      $viewParams = $this->_getViewParams($this->params['named']);
      $errset = false;

      $relevant_meta = 'host_value_id';
      if ($viewParams['instance'] == '' || $viewParams['instance'] == 'Site.Default') {
        $relevant_meta = 'site_value_id';
        $viewParams['instance'] = '';
        $viewParams['resource_set_id'] = null;
      }
      else if (!empty($viewParams['set_name'])) {
        $relevant_meta = 'set_value_id';
      }

      $scope = $this->currentUser['User']['scope_id'];
      $id = $viewParams['module_name'] . ':' . $viewParams['instance'];
      if (!empty($viewParams['host_id']))
        $id .= "({$viewParams['hostname']}-{$viewParams['host_id']})";
      else if (!empty($viewParams['set_name']))
        $id .= "({$viewParams['set_name']}-{$viewParams['resource_set_id']})";

      $history = array (
         'action'         => 'delete',
	 'previous_value' => $viewParams['module_name'].':'.$viewParams['instance'],
         'creator'        => $this->currentUser['User']['user_name'],
         'scope_id'       => $scope);

      switch ($relevant_meta) {
        case 'host_value_id':
	  $history['table_name']  = 'hosts';
	  $history['foreign_key'] = $viewParams['host_id'];
	  break;
	case 'resource_set_id':
	  $history['table_name']  = 'resource_sets';
	  $history['foreign_key'] = $viewParams['resource_set_id'];
	  break;
	default:
	  $history['table_name']  = 'swmodules';
	  $history['foreign_key'] = $viewParams['swmodule_id'];
      }

$this->log("delete($id)".print_r($viewParams,true));
      if (!$this->{$this->modelClass}->deleteall(array
	       ('SoftMeta.swmodule_id'     => $viewParams['swmodule_id'],
	        'SoftMeta.resource_set_id' => $viewParams['resource_set_id'],
	        'SoftMeta.instance'        => $viewParams['instance'],
		'SoftMeta.scope_id'        => $scope),
               false,false)) {
        $this->Session->setFlash(__('Problem removing ',true).'meta entries');
	$errset = true;
      }
      if (!$errset) {
	$this->{$this->modelClass}->Swmodule->History->save($history);

        $this->Session->setFlash($viewParams['instance'].' ' . __('instance cleared', true));
        Cache::delete("work-$scope-{$this->modelClass}-$id");
        $this->redirect(array('controller' => 'hosts', 'action' => 'index'));
      }	
    }
  }

  function comment($id = null) {
    parent::comment($id);
  }

  function beforeFilter () {
    $this->theme = 'ilinux';
    if ($this->RequestHandler->isAjax()) {
      $this->Security->validatePost = false;
    }
    $this->Auth->allow ('ajaxattrs', 'ajaxinstance');

    parent::beforeFilter ();
  }

/////////////////////////////////////////////////////////////////////////////////////

  function ajaxattrs () {
    $this->data['dropDown']['meta_field_id'] = $this->SoftMeta->MetaField->find('list',
      array('fields' => array('MetaField.id', 'MetaField.parameter_name', 'MetaField.function'),
            'recursive' => -1,
            'conditions' => array(
	     'MetaField.table_name' => 'swmodules',
	     'MetaField.foreign_key' => $this->data['workObject']['Attrs']['swmodule_id']['data_value'],
	     'MetaField.scope_id' => $this->currentUser['User']['scope_id'])));
    $this->set('option_list', $this->data['dropDown']['meta_field_id']);
    $this->render('/soft_meta/ajaxoptgroups');
  }

  function ajaxinstance() {
    $this->set('option_list', $this->SoftMeta->find('list',
      array('fields' => array('DISTINCT SoftMeta.id', 'SoftMeta.instance'),
            'recursive' => -1)));
    $this->render('/soft_meta/ajaxlist');
  }


/////////////////////////////////////////////////////////////////////////////////////

  private function _getViewParams($urlParams) {

    $instances = array();

    $viewParams = array('module_name' => $urlParams['swmodule'], 'inst_index' => array(),
      'instances' => array());
    if (isset($urlParams['host_id'])) {
      $viewParams['host_id'] = $urlParams['host_id'];
      $query = $this->{$this->modelClass}->ResourceSet->SetMember->Host->find('first',
          array('conditions'=> array('Host.id' => $urlParams['host_id'], 'Host.scope_id' =>
	        $this->currentUser['User']['scope_id']), 'fields' => array('hostname'),
		'recursive' => -1));
      $viewParams['hostname'] = $query['Host']['hostname'];

      // Check for set memberships
      //  TBD:  look for soft_meta entries bound to named sets that are bound to
      //  the host through the default set
      
      if (!isset($urlParams['set_name'])) {
        $query = $this->{$this->modelClass}->ResourceSet->find('first',
          array('conditions' => array('SetMember.foreign_key' => $viewParams['host_id'],
	  	  'SetMember.table_name' => 'hosts',
	  	  'SetBinding.table_name' => 'swmodules',
		  'module_name' => $viewParams['module_name'],
	          'ResourceSet.scope_id' => $this->currentUser['User']['scope_id'],
		  'set_name !=' => null),
		'joins' => array(array('table' => 'set_members', 'alias' =>
		  'SetMember', 'type' => 'inner', 'conditions' =>
		  'SetMember.resource_set_id = ResourceSet.id'),
		 array('table' => 'set_bindings', 'alias' =>
		  'SetBinding', 'type' => 'inner', 'conditions' =>
		  'SetBinding.resource_set_id = ResourceSet.id'),
		 array('table' => 'swmodules', 'alias' =>
		  'Swmodule', 'type' => 'inner', 'conditions' =>
		  'Swmodule.id = SetBinding.foreign_key')),
		'fields' => array('ResourceSet.id', 'ResourceSet.set_name'), 'recursive' => -1));
	if (!empty($query))
	  $viewParams['set_name'] = $query['ResourceSet']['set_name'];
      }
      // Pick up the host's resource set ID (name=null, SetMember={host_id})
      if ($query = $this->{$this->modelClass}->ResourceSet->find('first',
            array('conditions' => array('SetMember.foreign_key' => $viewParams['host_id'],
	  	  'SetMember.table_name' => 'hosts',
	          'ResourceSet.scope_id' => $this->currentUser['User']['scope_id'],
		  'set_name' => null),
		'joins' => array(array('table' => 'set_members', 'alias' =>
		  'SetMember', 'type' => 'inner', 'conditions' =>
		  'SetMember.resource_set_id = ResourceSet.id')),
		'fields' => array('ResourceSet.id'), 'recursive' => -1)))
	$viewParams['resource_set_id'] = $query['ResourceSet']['id'];
    }
    if (isset($urlParams['set_name'])) {
      $viewParams['set_name'] = $urlParams['set_name'];
      if (!isset($viewParams['resource_set_id']) &&
        ($query = $this->{$this->modelClass}->ResourceSet->find('first', array(
	'conditions' => array('ResourceSet.scope_id' => $this->currentUser['User']['scope_id'],
	      'ResourceSet.set_name' => $viewParams['set_name']),
	'fields' => array('id'), 'recursive' => -1))))
        $viewParams['resource_set_id'] = $query['ResourceSet']['id'];
    }

    if (!isset($urlParams['instance'])) {
      if (!isset($viewParams['hostname']))
	$query = $this->{$this->modelClass}->query("SELECT DISTINCT function,instance FROM soft_meta 
             JOIN swmodules ON swmodules.id=soft_meta.swmodule_id
	     JOIN meta_fields ON meta_fields.id=soft_meta.meta_field_id
	     WHERE soft_meta.scope_id=".$this->currentUser['User']['scope_id'].
	     " AND module_name='".$viewParams['module_name'].
	     "' AND instance!=''".
	     " ORDER BY function,instance;");
      else
	$query = $this->{$this->modelClass}->query("SELECT DISTINCT function,instance FROM soft_meta 
             JOIN swmodules ON swmodules.id=soft_meta.swmodule_id
	     JOIN meta_fields ON meta_fields.id=soft_meta.meta_field_id
	     JOIN resource_sets ON resource_sets.id=soft_meta.resource_set_id
	     JOIN set_members ON set_members.resource_set_id=resource_sets.id
	     WHERE soft_meta.scope_id=".$this->currentUser['User']['scope_id'].
	     " AND set_members.table_name='hosts' and set_members.foreign_key=".$viewParams['host_id'].
	     " AND module_name='".$viewParams['module_name'].
	     "' AND instance!=''".
	     " ORDER BY function,instance;");
      $key = 0;
      foreach ($query as $item) {
        $viewParams['inst_index'][$key] =
         $viewParams['instances'][$item['meta_fields']['function']][$key] = $item['soft_meta'][MAIN_FUNCTION];
	$key++;
      }
      $viewParams['inst_index'][$key] = 'Site.Default';
      $viewParams['instances'][__('(More)',true)][$key] = __('Site Default',true);
      if ($this->Acl->check($this->currentUser['User']['user_name'], "controllers/SoftMeta/edit", '*')) {
        $key++;
        $viewParams['inst_index'][$key] = '_Create._';
        $viewParams['instances'][__('(More)',true)][$key] = __('Create',true);
      }
    }
    else {
      $viewParams['inst_index'][0] =
       $viewParams['instances'][''][0] = $urlParams['instance'];
    }

    if (isset($this->data[$this->{$this->modelClass}->table]['viewParamId']))
      $viewParamId = $this->data[$this->{$this->modelClass}->table]['viewParamId'];
    else if (isset($urlParams['viewParamId']))
      $viewParamId = $urlParams['viewParamId'];
    else
      $viewParamId = 0;

    // TBD range-check
    $viewParams['instance'] = $viewParams['inst_index'][$viewParamId];
    $viewParams['viewParamId'] = $viewParamId;
    $query = $this->{$this->modelClass}->Swmodule->find('first',array ('conditions' =>
	    array ('module_name' => $viewParams['module_name'],
	     'scope_id' => $this->currentUser['User']['scope_id']), 'recursive' => -1));
    $viewParams['swmodule_id'] = $query['Swmodule']['id'];
    return $viewParams;
  }

  
/////////////////////////////////////////////////////////////////////////////////////

  function _softWorkObject ($scope, $id, $record, $viewParams) {

/// code mostly from AppModel::getWorkObject

    // Cache the object as schema-{scope}-{model} if called with blank id
    // or as work-{scope}-{model}-{id} if called with id

    if ((empty($id) && !$object = Cache::read("schema-$scope-".$this->modelClass)) ||
        (!empty($id) && !$object = Cache::read("work-$scope-{$this->modelClass}-$id"))) {

      // Return failure if $viewParams is null (e.g. Submit button pressed
      // after cache expiration)
      if (empty($viewParams))
        return null;

      // Invoke the top-level function to build the array
      $object = $this->{$this->modelClass}->getWorkObject($scope, null, null);

      $object['id'] = $id;
      $object['viewParams'] = $viewParams;

      // Clear out the entire Attrs array of fields and start over
      $object['Attrs'] = array();

      $field_options = array(
      // Keywords recognized in the options field
         'bool_style', // Style to use for true/false table lookup
         'fkfield',    // Field name to use in index/view displays for joined fktable
         'groupsep',   // Insert a group separator on edit display
         'habtm',      // Third table to use (along with fktable) for multi-select HasAndBelongsToMany
         'index_omit', // Omit from index display any records matching this array list
         'label',      // Label (in English prior to translation) to use on index/view/edit
         'length',     // Limit input length on edit
         'mandatory',  // If set, field length must be greater than zero
	 'optvalues',  // Option values for drop-down selection list
         'primary',    // Highlight/hyperlink this field on index
         'ro',         // Read-only (omit from edit)
         'rules',      // Validation rule parameters (as specified in Cake book section 4.1.4)
         'style',      // Can specify one of:  autocomplete
         'validate'    // One or more CakePHP built-in validation rules (see Cake book section 4.1.4),
                       //  or regexp format
      );

      $bool_model_loaded = false;
      $meta = array();
      $last_func = '';

      // Logic is almost the same except for this pair of queries (which takes the place
      // of two queries in the existing procedure)

      $this->{$this->modelClass}->query("CALL sw_meta_list(".
      	    $scope.",".
	    (isset($viewParams['host_id']) ? $viewParams['host_id'] : 'NULL').",'".
     	    (isset($viewParams['set_name']) ? $viewParams['set_name'] : "''")."','".
     	    $viewParams['module_name']."','".
     	    $viewParams['instance']."');");
      $params = $this->{$this->modelClass}->query("SELECT MetaField.meta_field_id,MetaField.parameter_name,MetaField.function,
             MetaField.field_type_id,MetaField.site_value,MetaField.set_value,MetaField.default_value,
	     MetaField.site_value_id,MetaField.set_value_id,MetaField.host_value_id,MetaField.data_value,Opts.options
            FROM tmp.sw_meta_list_result AS MetaField
            JOIN meta_fields AS Opts ON Opts.id=MetaField.meta_field_id
	    ORDER BY function,display_seq,parameter_name;");

      if ($viewParams['instance'] == '_Create._') {
          $object['Attrs']['instance'] = array(
	    'default_value'   => '1',
	    'data_value'      => '1',
	    'length'          => 45,
	    'field_type_id'   => 1,
	    'meta_field_id'   => null,   // TBD
	    'options'	      => array('mandatory' => true, 'groupsep' => true));

          $object['validate'] = array('instance' =>
	     array('rule' => '/^[a-z0-9._\$\/@+-]+$/i', 'allowEmpty' => false));
      }
      foreach ($params as $key => $item) {
	  if ($item['MetaField']['parameter_name'] == '')
	    continue;
          $field = $item['MetaField']['function'] == MAIN_FUNCTION
              ? $item['MetaField']['parameter_name']
	      : $item['MetaField']['function'].'::'.$item['MetaField']['parameter_name'];
          $object['Attrs'][$field]['data_value'] = $item['MetaField']['data_value'];
	  if ($this->currentUser['User']['user_name'] == 'ilclient' ||
	      ($item['MetaField']['field_type_id'] != FTYPE_PASSWORD &&
	       $item['MetaField']['field_type_id'] != FTYPE_RESTRICTED &&
	       $item['MetaField']['field_type_id'] != FTYPE_ARRAY_RESTRICTED))
              $object['xmlBrief'][$field] = $item['MetaField']['data_value'];

	  if ($viewParams['instance'] == 'Site.Default')
	    $object['Attrs'][$field]['default_value'] = $item['MetaField']['default_value'];
          else if (isset($viewParams['host_id']) && $item['MetaField']['set_value'] != null)
	    $object['Attrs'][$field]['default_value'] = $item['MetaField']['set_value'];
          else if ($item['MetaField']['site_value'] != null)
	    $object['Attrs'][$field]['default_value'] = $item['MetaField']['site_value'];
          else if ($item['MetaField']['default_value'] != null)
	    $object['Attrs'][$field]['default_value'] = $item['MetaField']['default_value'];
	  if ($item['MetaField']['site_value_id'] != null)
	    $object['Attrs'][$field]['site_value_id'] = $item['MetaField']['site_value_id'];
	  if ($item['MetaField']['set_value_id'] != null)
	    $object['Attrs'][$field]['set_value_id'] = $item['MetaField']['set_value_id'];
	  if ($item['MetaField']['host_value_id'] != null)
	    $object['Attrs'][$field]['host_value_id'] = $item['MetaField']['host_value_id'];

	  // If field type is boolean, determine bool_style
	  if ($item['MetaField']['field_type_id'] == FTYPE_BOOLEAN) {
	    if (!$bool_model_loaded) {
		    $this->loadModel('BooleanValue');
		    $bool_model_loaded = true;
	    }
	    $boolquery = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('OR' => array ('true' => $item['MetaField']['default_value'],
		    'false' => $item['MetaField']['default_value'])), 'recursive' => -1));
	    if (!empty($boolquery)) {
	      $object['Attrs'][$field]['bool_style'] = $boolquery['BooleanValue']['bool_style'];
	      if ($object['Attrs'][$field]['default_value'] == $boolquery['BooleanValue']['true'])
	        $object['Attrs'][$field]['default_value'] = true;
	      else
	    	$object['Attrs'][$field]['default_value'] = false;
	    }
	  }

	  // Translate into true or false

	  if ($item['MetaField']['field_type_id'] == FTYPE_BOOLEAN &&
	        isset($object['Attrs'][$field]['bool_style']))
	    $object['Attrs'][$field]['data_value'] =
	    			$item['MetaField']['data_value'] == $boolquery['BooleanValue']['true'];

	  $fieldLengthByTypes = array(0, 11, 0, 17, 25, 0, 0, 0, 0, 0, 0, 32, 0);
	  if (isset($fieldLengthByTypes[$item['MetaField']['field_type_id']]))
	    $object['Attrs'][$field]['length'] = 
	      $fieldLengthByTypes[$item['MetaField']['field_type_id']];
	  else
	    $object['Attrs'][$field]['length'] = 0;

          $object['Attrs'][$field]['field_type_id'] = $item['MetaField']['field_type_id'];
          $object['Attrs'][$field]['meta_field_id'] = $item['MetaField']['meta_field_id'];
	  $object['Attrs'][$field]['groupsep'] = false;

	  // Pick up field options
	  $object['Attrs'][$field]['options'] = 
	    il_opt_parse($field_options, $item['Opts']['options']);

	  if (isset($object['Attrs'][$field]['options']['length']))
	    $object['Attrs'][$field]['length'] = $object['Attrs'][$field]['options']['length'][0];

	  // Set a group separator if the function name changes
	  if (!empty($last_func) && $item['MetaField']['function'] != $last_func) 
	    $object['Attrs'][$last_field]['options']['groupsep'] = true;
	  $last_func = $item['MetaField']['function'];
	  $last_field = $field;
      }

      // Look for validation rules, primaryField, autoComplete
      foreach ($object['Attrs'] as $field => $attr) {
        if (isset($attr['options']['mandatory']))
	  $object['Attrs'][$field]['mandatory'] = true;
        if (isset($attr['options']['validate'])) {
	    $val_entry = array();
	    if (isset($object['Attrs'][$field]['options']['rules']))
	      switch ($object['Attrs'][$field]['options']['validate'][0]) {
	        case 'cc':
	        case 'extension':
	        case 'inList':
	        case 'multiple':
		  // Rules are appended as a sub-array
	          $object['Attrs'][$field]['options']['validate'][] =
	            $object['Attrs'][$field]['options']['rules'];
	          $val_entry['rule'] = $object['Attrs'][$field]['options']['validate'];
		  break;
		default:
		  // Rules are tacked on as separate elements onto the array
	          $val_entry['rule'] = array_merge(
	            $object['Attrs'][$field]['options']['validate'],
	            $object['Attrs'][$field]['options']['rules']);
	      }
	    else
	      $val_entry['rule'] = $object['Attrs'][$field]['options']['validate'][0];
	    if (!isset($object['Attrs'][$field]['mandatory']) ||
	        $object['Attrs'][$field]['mandatory'] == false)
	      $val_entry['allowEmpty'] = true;
	    $object['validate'][$field] = $val_entry;
        }
	if (isset($attr['options']['primary']))
	  $object['primaryField'] = $field;

	// Enable autocomplete Ajax logic if needed
	if (isset($object['Attrs'][$field]['options']['style']) &&
	            $object['Attrs'][$field]['options']['style'][0] == 'autocomplete')
	  $object['enableAutocomplete'] = true;
      }

      if (!empty($object))
        Cache::write("work-$scope-{$this->modelClass}-$id", $object);
    }
    return $object;
  }
}
?>
