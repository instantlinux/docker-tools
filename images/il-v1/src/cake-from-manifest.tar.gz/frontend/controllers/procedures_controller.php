<?php
// $Id: procedures_controller.php 162 2011-07-01 22:08:53Z richb $

class ProceduresController extends AppController {
  var $helpers = array ('Html', 'Form');
  var $name = 'Procedure';
  var $view = 'Theme';

  function index() {
    parent::index();
  }

  function invoke ($id = null) {
    // Use the Ajax layout which eliminates all the css and debugging output
    $this->layout = 'ajax';

    if ($id) {
      $query = $this->{$this->modelClass}->findById($id);
    }
    else {
      // Pick up any params passed from the URL, strip out the "args:n"
      $urlParams = $this->params['named'];
      unset($urlParams['args']);
      $urlParams['scope_id'] = $this->currentUser['User']['scope_id'];
      $query = $this->{$this->modelClass}->find('first',
         array ('conditions' => $urlParams, 'recursive' => -1));
    }
    if (empty($query)) {
# TBD: pass error to user
#      $this->_outputMessage = __("procedure not found", true);
      $this->log("procedure::invoke procedure($id) not found, params ".print_r($this->params['named'],true));
      $this->cakeError('error500');
    }

    // First argument is always scope_id; include any additional ones from URL
    $args = '('.$this->currentUser['User']['scope_id'].(isset($this->params['named']['args']) ?
         ','.$this->params['named']['args'] : '').')';

    if ($query['Procedure']['use_master'])
      $this->{$this->modelClass}->useDbConfig = 'master';

    switch ($query['Procedure']['proc_type']) {
      case 'procedure':

#   See IL-174 error message "SQL Error: 2014: Commands out of sync; you can't
#      run this command now

# TBD get something Cake-native like this working.

        $db = ConnectionManager::getDataSource($this->{$this->modelClass}->useDbConfig);
#        $runquery = $db->rawQuery ("CALL ".$query['Procedure']['proc_name'].$args);
#	$output = array();
#	while ($row = $db->fetchRow())
#	  $output[] = $row;
#	$this->set('output', $output);

#  4/19/2011 I'm punting and shelling out to the stock MySQL client.
        $cmd = "mysql -s --raw --default-character-set=utf8 -u ".$db->config['login'].
	  " -p".$db->config['password'].
	  " -h".$db->config['host'].
	  " ".$db->config['database'].
	  " -e 'CALL ".$query['Procedure']['proc_name'].$args."' 2>&1";
        exec ($cmd, &$output, &$ret);
        $this->set('output', implode("\n", $output));
	if ($ret != 0) {
	  $this->log(__("failure running", true)." ".$query['Procedure']['proc_name'].$args);
	  $this->log(__("output", true)." ".implode("\n", $output));
# TBD: pass error to user
#	  $this->_outputMessage = implode("\n", $output);
	  $this->cakeError('error500');
	}
        break;
      case 'function':
        $runquery = $this->{$this->modelClass}->query ("SELECT ".$query['Procedure']['proc_name'].$args." AS result;");
	if (!$runquery) {
	  $this->log(__("failure running", true)." ".$query['Procedure']['proc_name'].$args);
	  $this->cakeError('error500');
	}
        $this->set('output', $runquery[0][0]['result']);
        break;
    }
  }

  function view($id = null) {
    parent::view($id);
  }

  function add() {
    parent::add();
  }

  function edit($id = null) {
    parent::edit($id);
  }

  function delete($id = null) {
    parent::delete($id);
  }

  function comment($id = null) {
    parent::comment($id);
  }

  function beforeFilter () {
    $this->theme = 'ilinux';

    parent::beforeFilter ();
  }
}
?>
