<?php
// $Id: net_devices_controller.php 233 2011-10-21 20:34:19Z richb $
class NetDevicesController extends AppController {
  var $helpers = array ('Html', 'Form');
  var $name = 'NetDevice';
  var $view = 'Theme';

  function index() {
    parent::index();
  }
  function view($id = null) {
    parent::view($id);

    // Override 'device_name' with virtual field 'device' to pick up sub-interface number
    $this->data['workObject']['Attrs']['device_name']['data_value'] =
        $this->data['workObject']['Records']['NetDevice']['device'];
  }

//////////////////////////////////////////////////////////////////////////

  function add() {
    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Meta->useDbConfig = 'master'; 
      $this->{$this->modelClass}->History->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Ipv6->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv6->currentUser = $this->currentUser;

      if ($this->data['workObject']['Attrs']['ip_address']['data_value'] !=  null)
	$this->data['Ipv4']['id'] = $this->data['workObject']['Attrs']['ip_address']['data_value'];
      if ($this->data['workObject']['Attrs']['ipv6_address']['data_value'] !=  null)
	$this->data['Ipv6']['id'] = $this->data['workObject']['Attrs']['ipv6_address']['data_value'];

      # Apply some rules:
      # - mac_address needs to be NULL rather than blank in order for
      #   dup-detection to work
      # - Only one interface can be primary, and it can't be a sub-interface

      if ($this->data['workObject']['Attrs']['mac_address']['data_value'] == '')
	      $this->data['workObject']['Attrs']['mac_address']['data_value'] = null;
      if ($this->data['workObject']['Attrs']['subint_num']['data_value'] != 0)
	      $this->data['workObject']['Attrs']['pxe_primary']['data_value'] = 0;
    }
    parent::add();

    // Update the dropDown choices to include only unassigned IPs

    $this->data['dropDown']['ip_address'] = $this->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	      array('Ipv4.net_device_id' => null,
	            'Ipv4.scope_id' => $this->currentUser['User']['scope_id'])));
    $this->data['dropDown']['ipv6_address'] = $this->NetDevice->Ipv6->find('list',
              array('fields' => array('Ipv6.ipv6_address'), 'conditions' =>
	      array('Ipv6.net_device_id' => null,
	            'Ipv6.scope_id' => $this->currentUser['User']['scope_id'])));

    // Set some default values for the form: first domain, first available IP,
    // first network

    $domain = $this->NetDevice->Domain->find('first',
	       array('fields' => array('id', 'domain'), 'conditions' =>
	       array('Domain.inaddr' => '0',
	             'Domain.scope_id' => $this->currentUser['User']['scope_id']),
	       'recursive' => -1));
    $network = $this->NetDevice->Subnet->find('first',
              array('fields' => array('id', 'network'), 'conditions' =>
	       array('Subnet.scope_id' => $this->currentUser['User']['scope_id']),
	       'recursive' => -1));

    $ipv4_ids = array_keys ($this->data['dropDown']['ip_address']);
    $this->data['workObject']['Attrs']['ip_address']['data_value'] = $ipv4_ids[0];
//  $ipv6_ids = array_keys ($this->data['dropDown']['ipv6_address']);
//  $this->data['workObject']['Attrs']['ipv6_address']['data_value'] = $ipv6_ids[0];
    $this->data['workObject']['Attrs']['domain_id']['default_value'] = $domain['Domain']['id'];
    $this->data['workObject']['Attrs']['subnet_id']['default_value'] = $network['Subnet']['id'];
  }

//////////////////////////////////////////////////////////////////////////

  function edit($id = null) {
    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Meta->useDbConfig = 'master'; 
      $this->{$this->modelClass}->History->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Ipv6->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv6->currentUser = $this->currentUser;

      // Fetch object attributes (from cache)
      $cached = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, null);

      // Disconnect/reconnect the old/new ipv4 entries

      if ($cached['Records']['Ipv4']['id'] != null) {
        // Clear the old IPv4 link to this device
	$this->data['Ipv4']['id'] = $cached['Records']['Ipv4']['id'];
        $this->data['Ipv4']['net_device_id'] = null;
      }
      // See if we need to write out a new one
      if ($this->data['workObject']['Attrs']['ip_address']['data_value'] !=  null) {	
        // Write out the above record before generating the new
        if (isset($this->data['Ipv4']) && !$this->{$this->modelClass}->Ipv4->save($this->data['Ipv4'])) {
          $this->Session->setFlash(__('Problem updating', true) . ' '.__('Ipv4').' '. __('entry', true));
          return;
        }
	$this->data['Ipv4']['id'] = $this->data['workObject']['Attrs']['ip_address']['data_value'];
        $this->data['Ipv4']['net_device_id'] = $id;
      }

      // Repeat for ipv6 entries

      if ($cached['Records']['Ipv6']['id'] != null) {
        // Clear the old Ipv6 link to this device
	$this->data['Ipv6']['id'] = $cached['Records']['Ipv6']['id'];
        $this->data['Ipv6']['net_device_id'] = null;
      }
      if ($this->data['workObject']['Attrs']['ipv6_address']['data_value'] !=  null) {	
        if (isset($this->data['Ipv6']) && !$this->{$this->modelClass}->Ipv6->save($this->data['Ipv6'])) {
          $this->Session->setFlash(__('Problem updating', true) . ' '.__('Ipv6').' '. __('entry', true));
          return;
        }
	$this->data['Ipv6']['id'] = $this->data['workObject']['Attrs']['ipv6_address']['data_value'];
        $this->data['Ipv6']['net_device_id'] = $id;
      }

      if ($this->data['workObject']['Attrs']['mac_address']['data_value'] == '')
	      $this->data['workObject']['Attrs']['mac_address']['data_value'] = null;
      if ($this->data['workObject']['Attrs']['subint_num']['data_value'] != 0)
	      $this->data['workObject']['Attrs']['pxe_primary']['data_value'] = 0;
    }

    // Write out any deassigned ipv4/ipv6 records prior to the saveall().
    // CakePHP can only make assignments to the current model, it won't deassign.
    if (isset($this->data['Ipv4']) && $this->data['Ipv4']['net_device_id'] == null) {
      if (!$this->{$this->modelClass}->Ipv4->save($this->data['Ipv4'])) {
        $this->Session->setFlash(__('Problem updating', true) . ' '.__('Ipv4').' '. __('entry', true));
        return;
      }
      unset($this->data['Ipv4']);
    }
    if (isset($this->data['Ipv6']) && $this->data['Ipv6']['net_device_id'] == null) {
      if (!$this->{$this->modelClass}->Ipv6->save($this->data['Ipv6'])) {
        $this->Session->setFlash(__('Problem updating', true) . ' '.__('Ipv6').' '. __('entry', true));
        return;
      }
      unset($this->data['Ipv6']);
    }

    // Pass any newly assigned ipv4/ipv6 entries plus updates to NetDevice to saveall()
    parent::edit($id);

    // Grab the IP address assigned to this interface, then the
    // unassigned ones, and pass them to the view as ['dropDown']['ipv4_id'].
    $existing_ipv4s = $this->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	        array ('Ipv4.net_device_id' => array ($id),
	               'Ipv4.scope_id' => $this->currentUser['User']['scope_id'])));
    $this->data['dropDown']['ip_address'] = array_replace($existing_ipv4s, $this->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	       array('Ipv4.net_device_id' => null,
	             'Ipv4.scope_id' => $this->currentUser['User']['scope_id']))));

    // Repeat for IPv6
    $existing_ipv6s = $this->NetDevice->Ipv6->find('list',
              array('fields' => array('Ipv6.ipv6_address'), 'conditions' =>
	        array ('Ipv6.net_device_id' => array ($id),
	               'Ipv6.scope_id' => $this->currentUser['User']['scope_id'])));
    $this->data['dropDown']['ipv6_address'] = array_replace($existing_ipv6s, $this->NetDevice->Ipv6->find('list',
              array('fields' => array('Ipv6.ipv6_address'), 'conditions' =>
	       array('Ipv6.net_device_id' => null,
	             'Ipv6.scope_id' => $this->currentUser['User']['scope_id']))));
  }

//////////////////////////////////////////////////////////////////////////

  function delete($id = null) {
    if ($id) {
      $this->{$this->modelClass}->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Ipv6->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Ipv6->currentUser = $this->currentUser;
      $this->{$this->modelClass}->id = $id;

      # Disconnect the ipv4/ipv6 entries if present
      $devinfo = $this->NetDevice->read();
      if ($devinfo['Ipv4']['id'] != null) {
        # Clear the old IPv4 link to this device
	$this->data['Ipv4']['id'] = $devinfo['Ipv4']['id'];
        $this->data['Ipv4']['net_device_id'] = null;
        $this->NetDevice->Ipv4->save ($this->data);
      }
      if ($devinfo['Ipv6']['id'] != null) {
        # Clear the old IPv6 link to this device
	$this->data['Ipv6']['id'] = $devinfo['Ipv6']['id'];
        $this->data['Ipv6']['net_device_id'] = null;
        $this->NetDevice->Ipv6->save ($this->data);
      }
    }
    parent::delete($id);
  }

  function comment($id = null) {
    parent::comment($id);
  }

  function beforeFilter () {
    $this->theme = 'ilinux';

    parent::beforeFilter ();
  }
}
?>
