<?php
// $Id: hosts_controller.php 233 2011-10-21 20:34:19Z richb $

class HostsController extends AppController {
  var $helpers = array ('Html','Form');
  var $name = 'Host';
  var $components = array ('Auth');
  var $view = 'Theme';

  function index() {
    parent::index();
    unset($this->data['workObject']['Attrs']['module_bindings']);
    unset($this->data['workObject']['Attrs']['resource_sets']);
  }

//////////////////////////////////////////////////////////////////////////////////////

  function view($id = null) {
    $this->Host->Location->Behaviors->attach('Tree', array('scope' => 'Location.scope_id = '.
                  $this->currentUser['User']['scope_id']));
    parent::view($id);

    $this->Host->query ("CALL host_module_list(".$this->currentUser['User']['scope_id'].",".$id.");");
    $this->set ('software', $this->Host->query (
  	      "SELECT set_name,GROUP_CONCAT(module_name ORDER BY module_name) AS modules
	       FROM tmp.host_module_list_result AS result GROUP BY set_name;"));

    $meta_count = $this->Host->query("SELECT module_name,COUNT(data_value) AS count
        FROM soft_meta JOIN swmodules ON swmodules.id=soft_meta.swmodule_id
        JOIN resource_sets ON resource_sets.id=soft_meta.resource_set_id
        JOIN set_members ON set_members.resource_set_id=resource_sets.id
        WHERE set_members.foreign_key=$id
        AND set_members.table_name='hosts' AND NOT set_members.disabled GROUP BY module_name;");
    $swmetaCount = array ();
    foreach ($meta_count as $item)
      $swmetaCount[$item['swmodules']['module_name']] = $item[0]['count'];
    $this->set('swmetaCount', $swmetaCount);
  }

//////////////////////////////////////////////////////////////////////////////////////

  function add($id = null) {
    if (!empty($this->data)) {
      $this->{$this->modelClass}->NetDevice->useDbConfig = 'master'; 
      $this->{$this->modelClass}->NetDevice->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->SetBinding->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->SetMember->ResourceSet->currentUser = $this->currentUser;
      if ($key = array_search('Tree', $this->{$this->modelClass}->Location->actsAs)) {
         unset($this->{$this->modelClass}->Location->actsAs[$key]); 
         $this->{$this->modelClass}->Location->Behaviors->attach("Tree", array('scope' =>
            'scope_id='.$this->currentUser['User']['scope_id']));
      }

      $errset = false;

      // Save a copy of form values entered into the workObject attributes
      $attrs = $this->data['workObject']['Attrs'];
      $cached = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], null, null);
      if (empty($cached)) {
        $this->Session->setFlash(__('Object went away, could identify attributes', true));
        $errset = true;
      }

      if ($this->data['NetDevice'][0]['mac_address'] == '')
        $this->data['NetDevice'][0]['mac_address'] = null;
      $this->data['NetDevice'][0]['domain_id'] = $this->data['workObject']['Attrs']['domain_id']['data_value'];
      $this->data['NetDevice'][0]['scope_id'] = $this->currentUser['User']['scope_id'];

      ##############################
      # Save the primary data records including meta, history, net_device
      parent::add($redir = false);
      ##############################

      # Now perform some operations that require the new record ID - set membership, IP binding

      if (!$new_hostid = $this->Host->getInsertID())
        $errset = true;

      # Create a null-named resource_set entry
      $records = array();
      $records['ResourceSet'] = array ( 'set_name' => null,
       'precedence' => 1000, 'scope_id' => $this->currentUser['User']['scope_id']);
      $records['SetMember'][] = array ('foreign_key' => $new_hostid, 'table_name' => 'hosts',
            'scope_id' => $this->currentUser['User']['scope_id']);

      // Load the set_bindings table with any selected modules
      $field = 'module_bindings';
      $model = Inflector::classify($cached['Attrs'][$field]['habtm']);
      if (!empty($attrs[$field]['data_value'])) {
        foreach ($attrs[$field]['data_value'] as $key => $item) {
          $records[$model][$key]['table_name'] = 'swmodules';
          $records[$model][$key]['foreign_key'] = $item;
	  $records[$model][$key]['scope_id'] = $this->currentUser['User']['scope_id'];
	}
      }

      if (!$errset &&
          !$this->Host->SetMember->ResourceSet->saveall($records)) {
        $this->Session->setFlash('Problem saving resource_sets');
	$errset = true;
      }

      # The 'saveall' function won't recurse to a second level
      #  (host->net_device->ipv4) so this item needs saving separately.

      if ($this->data['NetDevice']['0']['Ipv4']['id'] != 0) {
        $this->data['NetDevice']['0']['Ipv4']['net_device_id'] = $this->Host->NetDevice->getInsertID();
        if (!$errset && 
	    !$this->Host->NetDevice->Ipv4->save($this->data['NetDevice']['0'])) {
          $this->Session->setFlash('Problem updating ipv4');
	  $errset = true;
        }
      }

      if (!$errset) {
        $this->Session->setFlash('Host entry saved');
        $this->redirect(array('action' => 'index'));
      }
    }

    $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], null, null);

    // Populate the drop-down fields for foreign-key relationships
    $this->_getDropDown();

    // getDropDown by itself isn't specific enough for hosts controller,
    // overrides/additions below
    $scope = $this->currentUser['User']['scope_id'];
    $conditions = array('scope_id' => $scope);
    $this->data['dropDown']['domain_id'] = $this->Host->NetDevice->Domain->find('list',
              array('fields' => array('Domain.domain'), 'conditions' =>
	      array('Domain.inaddr' => '', 'Domain.scope_id' => $scope)));
    $this->data['dropDown']['subnet_id'] = $this->Host->NetDevice->Subnet->find('list',
              array('fields' => array('Subnet.network'), 'conditions' => $conditions));
    $this->data['dropDown']['ipv4_id'] = $this->Host->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	      array('Ipv4.net_device_id' => null, 'Ipv4.scope_id' => $scope)));
    $this->data['dropDown']['model_num_id'] = $this->Host->ModelNum->find('list',
              array('recursive' => 1, 'fields' => array('ModelNum.id', 'ModelNum.model_num','Vendor.vendor_name'),
	      'order' => array('vendor_name', 'model_num'),
	      'conditions' => array('ModelNum.scope_id' => $scope)));
    $this->data['dropDown']['distro_rev_id'] = $this->Host->DistroRev->find('list',
              array('fields' => array('DistroRev.id', 'version_no','distro_arch'),
	      'order' => array('distro_arch', 'version_no'), 'conditions' => $conditions));
    $this->data['dropDown']['netdev_type_id'] = $this->Host->NetDevice->NetdevType->find('list',
              array('fields' => array('NetdevType.netdev_type')));
    $this->data['dropDown']['resource_sets'] = $this->Host->SetMember->ResourceSet->find('list',
              array('fields' => array('set_name'), 'conditions' =>
              array('set_name !=' => null, 'set_name !=' => 'default',
	            'scope_id' => $scope)));

    $this->data['workObject']['Attrs']['module_bindings']['fktable'] = 'swmodules'; //fake
    $this->data['workObject']['Attrs']['module_bindings']['options']['groupsep'] = true;
    $this->data['dropDown']['module_bindings'] = $this->Host->SetMember->ResourceSet->SetBinding->Swmodule->find('list',
              array('fields' => array('Swmodule.module_name'),
	            'conditions' => $conditions));

    // Identify the FQDNs of all virtualization hosts
    $query = $this->Host->query ("CALL module_host_list(".$scope.",'virtualbox');");
    $query = $this->Host->query ("SELECT host_id,fqdn FROM tmp.module_host_list_result;");
    $sel_vmhosts = array();
    foreach ($query as $item) {
      $sel_vmhosts[$item['module_host_list_result']['host_id']] =
         $item['module_host_list_result']['fqdn'];
    }
    $this->data['dropDown']['parent_id'] = $sel_vmhosts;

    // Default values
    foreach ($this->data['workObject']['Attrs'] as $field => $attr)
      if (isset($attr['default_value']))
        $this->data['workObject']['Attrs'][$field]['data_value'] = $attr['default_value'];

    // Generate SSH keys
    $lastline = exec("rm -f /tmp/ilnewkey;ssh-keygen -t rsa -f /tmp/ilnewkey -N '' >/dev/null; cat /tmp/ilnewkey", &$ssh_pem_rsa, &$retval );
    $lastline = exec("awk '{print $2}' /tmp/ilnewkey.pub ; rm /tmp/ilnewkey ; rm /tmp/ilnewkey.pub", &$ssh_key_rsa, &$retval);
    $lastline = exec("ssh-keygen -t dsa -f /tmp/ilnewkey -N '' >/dev/null; cat /tmp/ilnewkey", &$ssh_pem_dsa, &$retval );
    $lastline = exec("awk '{print $2}' /tmp/ilnewkey.pub ; rm /tmp/ilnewkey ; rm /tmp/ilnewkey.pub", &$ssh_key_dsa, &$retval);

    $this->data['workObject']['Attrs']['ssh_host_pem_rsa']['data_value'] = implode("\n", $ssh_pem_rsa);
    $this->data['workObject']['Attrs']['ssh_host_key_rsa']['data_value'] = $ssh_key_rsa[0];
    $this->data['workObject']['Attrs']['ssh_host_pem_dsa']['data_value'] = implode("\r\n", $ssh_pem_dsa);
    $this->data['workObject']['Attrs']['ssh_host_key_dsa']['data_value'] = $ssh_key_dsa[0];

    $macaddr_oui = $this->Host->Meta->MetaField->FieldType->Setting->findByParameterName('macaddr_oui');

    $this->data['NetDevice']['0']['device_name'] = '/dev/eth0';
    $this->data['NetDevice']['0']['mac_address'] = $macaddr_oui['Setting']['data_value'].':'.implode(str_split(str_pad(dechex(rand(0,16777216)),6,'0',STR_PAD_LEFT),2),':');
    $this->data['NetDevice']['0']['domain_id'] = key($this->data['dropDown']['domain_id']);
    $this->data['NetDevice']['0']['subnet_id'] = key($this->data['dropDown']['subnet_id']);
    $this->data['NetDevice']['0']['Ipv4']['id'] = key($this->data['dropDown']['ipv4_id']);
  }

//////////////////////////////////////////////////////////////////////////////////////

  function edit($id = null) {
    $this->Host->id = $id;
    if (!empty($this->data)) {
      $this->{$this->modelClass}->NetDevice->useDbConfig = 'master'; 
      $this->{$this->modelClass}->NetDevice->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->SetBinding->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->SetMember->ResourceSet->currentUser = $this->currentUser;
      if ($key = array_search('Tree', $this->{$this->modelClass}->Location->actsAs)) {
         unset($this->{$this->modelClass}->Location->actsAs[$key]); 
         $this->{$this->modelClass}->Location->Behaviors->attach("Tree", array('scope' =>
            'scope_id='.$this->currentUser['User']['scope_id']));
      }

      $errset = false;

      // Pick up saved copy of form values prior to edit
      $attrs = $this->data['workObject']['Attrs'];
      $cached = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, null);
      if (empty($cached)) {
        $this->Session->setFlash(__('Object went away, could identify attributes', true));
        $errset = true;
      }

      # Clear any pxe_primary flags seen after the first one
      $primaryint_seen = false;

      foreach ($this->data['NetDevice'] as $key => $device) {
        $this->data['NetDevice'][$key]['id'] = $cached['Records']['NetDevice'][$key]['id'];

        # Avoid dup-key errors for mac_address on sub-interfaces
        if ($device['mac_address'] == '')
          $this->data['NetDevice'][$key]['mac_address'] = null;

	# Check pxe_primary
	if ($device['pxe_primary']) {
	  if ($primaryint_seen)
	    $this->data['NetDevice'][$key]['pxe_primary'] = false;
	  else {
	    $primaryint_seen = true;
            $this->data['NetDevice'][$key]['domain_id'] = $this->data['workObject']['Attrs']['domain_id']['data_value'];
	  }
	  $this->data['NetDevice'][0]['scope_id'] = $this->currentUser['User']['scope_id'];
	}
      }
      // Primary domain is attached to NetDevice (above), not to host
      unset($this->data['workObject']['Attrs']['domain_id']);

      if (!$primaryint_seen) {
        $this->Session->setFlash(__('Primary network interface is required',true));
	$errset = true;
      }

      ##############################
      # Save the primary data records including meta, history, net_device
      if (!$errset)
        parent::edit($id, $redir = false);
      ##############################

      $records = array ();

      // Find the resource_set identifier for this host's module bindings
      $query = $this->{$this->modelClass}->query ("SELECT resource_sets.id FROM
        resource_sets JOIN set_members ON set_members.resource_set_id=resource_sets.id WHERE foreign_key=$id AND
        table_name=\"hosts\" AND set_name is null;");
      $resource_id = !empty($query) ? $query[0]['resource_sets']['id'] : null;
      if ($resource_id == null)
        $this->log("Host::edit data integrity error, null resource_id for host $id");

      // Flush all module bindings for this host
      if (!$errset && !empty($resource_id) &&
          !$this->Host->SetMember->ResourceSet->SetBinding->deleteall(array
              ('SetBinding.resource_set_id' => $resource_id,
	       'SetBinding.table_name' => 'swmodules'), false, false)) {
        $this->Session->setFlash(__('Problem purging ',true).'module_bindings');
	$errset = true;
      }

      // Load the set_bindings table with any selected modules
      $records['ResourceSet'] = array ('id' => $resource_id);
      $field = 'module_bindings';
      $model = Inflector::classify($cached['Attrs'][$field]['habtm']);
      if (!empty($attrs[$field]['data_value'])) {
        foreach ($attrs[$field]['data_value'] as $key => $item) {
          $records[$model][$key]['table_name'] = 'swmodules';
          $records[$model][$key]['foreign_key'] = $item;
	  $records[$model][$key]['scope_id'] = $this->currentUser['User']['scope_id'];
	}
      }

      if (!$errset && !empty($records) &&
          !$this->Host->SetMember->ResourceSet->saveall($records)) {
        $this->Session->setFlash(__('Problem saving ',true).'set_bindings');
	$errset = true;
      }

      # Re-bind any modified IP entries

      $records = array();
      foreach ($this->data['NetDevice'] as $key => $device) {
        # Disconnect/reconnect the old/new ipv4 entries
        if ((empty($cached['Records']['NetDevice'][$key]['Ipv4']) || $cached['Records']['NetDevice'][$key]['Ipv4']['id'] == null) &&
	    (isset($device['Ipv4']) && $device['Ipv4']['id'] != null))
	  $records[] = array ('id' => $device['Ipv4']['id'], 'net_device_id' => $device['id']);
        else if (!empty($cached['Records']['NetDevice'][$key]['Ipv4']) &&
                 $cached['Records']['NetDevice'][$key]['Ipv4']['id'] != null &&
	    (empty($device['Ipv4']) ||$device['Ipv4']['id'] == null))
	  $records[] = array ('id' => $cached['Records']['NetDevice'][$key]['Ipv4']['id'],
	                      'net_device_id' => null);
        else if (!empty($cached['Records']['NetDevice'][$key]['Ipv4']) &&
           !empty($device['Ipv4']) &&
	   $cached['Records']['NetDevice'][$key]['Ipv4']['id'] != 
	    $device['Ipv4']['id']) {
	  $records[] = array ('id' => $cached['Records']['NetDevice'][$key]['Ipv4']['id'],
	                      'net_device_id' => null);
	  $records[] = array ('id' => $device['Ipv4']['id'], 'net_device_id' => $device['id']);
        }
      }
      if (!$errset && !empty($records) && !$this->Host->NetDevice->Ipv4->saveall($records)) {
          $this->Session->setFlash('Problem updating ipv4');
	  $errset = true;
      }

      // TBD - write history records for IP, module_binding, resource_set updates

      if (!$errset) {
        $this->Session->setFlash(__('Host entry updated',true));
        $this->redirect(array('action' => 'index'));
      }
      else
        unset($this->data);
    }

    parent::edit($id);

    // getDropDown by itself isn't specific enough for hosts controller,
    // overrides/additions below
    $scope = $this->currentUser['User']['scope_id'];
    $conditions = array('scope_id' => $scope);

    $this->data['dropDown']['domain_id'] = $this->Host->NetDevice->Domain->find('list',
              array('fields' => array('Domain.domain'), 'conditions' =>
	      array('Domain.inaddr' => '', 'Domain.scope_id' => $scope)));
    $this->data['dropDown']['subnet_id'] = $this->Host->NetDevice->Subnet->find('list',
              array('fields' => array('Subnet.network'), 'conditions' => $conditions));

    // Grab the IP addresses assigned to existing interfaces, then the
    // unassigned ones, and pass them to the view as "ipv4_id"
    $net_device_ids = array ();
    foreach ($this->data['workObject']['Records']['NetDevice'] as $key => $item)
      $net_device_ids[$key] = $item['id'];

    $existing_ipv4s = $this->Host->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	        array ('Ipv4.net_device_id' => $net_device_ids,
		       'Ipv4.scope_id' => $scope)));
    $this->data['dropDown']['ipv4_id'] = array_replace($existing_ipv4s, $this->Host->NetDevice->Ipv4->find('list',
              array('fields' => array('Ipv4.ip_address'), 'conditions' =>
	       array('Ipv4.net_device_id' => null, 'Ipv4.scope_id' => $scope))));

    $this->data['dropDown']['model_num_id'] = $this->Host->ModelNum->find('list',
              array('recursive' => 1, 'fields' => array('ModelNum.id', 'ModelNum.model_num','Vendor.vendor_name'),
	      'order' => array('vendor_name', 'model_num'),
	      'conditions' => array('ModelNum.scope_id' => $scope)));
    $this->data['dropDown']['distro_rev_id'] = $this->Host->DistroRev->find('list',
              array('fields' => array('DistroRev.id', 'version_no','distro_arch'),
	      'order' => array('distro_arch', 'version_no'), 'conditions' => $conditions));
    $this->data['dropDown']['netdev_type_id'] = $this->Host->NetDevice->NetdevType->find('list',
              array('fields' => array('NetdevType.netdev_type')));
    $this->data['dropDown']['resource_sets'] = $this->Host->SetMember->ResourceSet->find('list',
              array('fields' => array('set_name'), 'conditions' =>
              array('set_name !=' => null, 'set_name !=' => 'default',
	            'scope_id' => $scope)));

    $this->data['workObject']['Attrs']['module_bindings']['fktable'] = 'swmodules'; //fake
    $this->data['workObject']['Attrs']['module_bindings']['options']['groupsep'] = true;
    $this->data['dropDown']['module_bindings'] = $this->Host->SetMember->ResourceSet->SetBinding->Swmodule->find('list',
              array('fields' => array('Swmodule.module_name'),
	            'conditions' => $conditions));

    // Identify the FQDNs of all virtualization hosts
    $query = $this->Host->query ("CALL module_host_list(".$this->currentUser['User']['scope_id'].",'virtualbox');");
    $query = $this->Host->query ("SELECT host_id,fqdn FROM tmp.module_host_list_result;");
    $sel_vmhosts = array();
    foreach ($query as $item)
      $sel_vmhosts[$item['module_host_list_result']['host_id']] =
         $item['module_host_list_result']['fqdn'];
    $this->data['dropDown']['parent_id'] = $sel_vmhosts;

    // Identify resource_set memberships
    $query = $this->Host->query ("SELECT set_members.id,set_members.resource_set_id FROM resource_sets
      JOIN set_members ON set_members.resource_set_id=resource_sets.id
      WHERE set_members.foreign_key=$id AND set_name IS NOT NULL
      AND set_members.table_name='hosts' AND NOT set_members.disabled
      AND resource_sets.scope_id=$scope;");
    $this->data['dropDown']['resource_sets_sel'] = array();
    foreach ($query as $item)
      $this->data['dropDown']['resource_sets_sel'][$item['set_members']['id']] =
           $item['set_members']['resource_set_id'];

    // Identify swmodule bindings
    $query = $this->Host->query ("SELECT set_bindings.id,set_bindings.foreign_key FROM resource_sets
      JOIN set_members on set_members.resource_set_id=resource_sets.id
      JOIN set_bindings on set_bindings.resource_set_id=resource_sets.id
      WHERE set_members.foreign_key=$id AND set_name IS NULL
      AND set_members.table_name='hosts' AND set_bindings.table_name='swmodules'
      AND NOT set_members.disabled AND NOT set_bindings.disabled
      AND resource_sets.scope_id=$scope;");
    $this->data['dropDown']['module_bindings_sel'] = array();
    foreach ($query as $item)
      $this->data['dropDown']['module_bindings_sel'][$item['set_bindings']['id']] =
           $item['set_bindings']['foreign_key'];

    // Populate the NetDevice records
    $this->data['NetDevice'] = $this->data['workObject']['Records']['NetDevice'];
    $this->data['workObject']['Attrs']['domain_id']['data_value'] =
       empty($this->data['NetDevice'][0]) ? null : $this->data['NetDevice'][0]['domain_id'];
  }

//////////////////////////////////////////////////////////////////////////////////////

  function delete($id = null) {
    if (!$id) {
      $this->Session->setFlash('Invalid id for Host');
      $this->redirect(array('action' => 'index'));
    }
    else {
      $this->{$this->modelClass}->NetDevice->useDbConfig = 'master'; 
      $this->{$this->modelClass}->NetDevice->Ipv4->useDbConfig = 'master'; 
      $this->{$this->modelClass}->NetDevice->Ipv6->useDbConfig = 'master'; 
      $this->{$this->modelClass}->Hostfile->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->SetBinding->useDbConfig = 'master'; 
      $this->{$this->modelClass}->SetMember->ResourceSet->SoftMeta->useDbConfig = 'master'; 
      $this->{$this->modelClass}->UsersGroup->useDbConfig = 'master'; 
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      $this->{$this->modelClass}->Hostfile->currentUser = $this->currentUser;
      $this->{$this->modelClass}->UsersGroup->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->Ipv4->currentUser = $this->currentUser;
      $this->{$this->modelClass}->NetDevice->Ipv6->currentUser = $this->currentUser;
      $this->{$this->modelClass}->SetMember->currentUser = $this->currentUser;
      $this->{$this->modelClass}->SetMember->ResourceSet->currentUser = $this->currentUser;
      $this->{$this->modelClass}->SetMember->ResourceSet->SoftMeta->currentUser = $this->currentUser;
      $this->{$this->modelClass}->UsersGroup->currentUser = $this->currentUser;

      if ($key = array_search('Tree', $this->{$this->modelClass}->Location->actsAs)) {
         unset($this->{$this->modelClass}->Location->actsAs[$key]); 
         $this->{$this->modelClass}->Location->Behaviors->attach("Tree", array('scope' =>
            'scope_id='.$this->currentUser['User']['scope_id']));
      }
      unset($this->Host->hasMany['Children']);

      $errset = false;

      # Ensure that the specified id is in scope
      if (!$hostinfo = $this->Host->find('first', array('conditions' =>
            array($this->modelClass.'.id' => $id,
	          $this->modelClass.'.scope_id' => $this->currentUser['User']['scope_id']),
          'recursive' => -1))) {
        $this->Session->setFlash(__('Invalid id',true));
	$id = null;
        $errset = true;
      }
      # TBD - give decent error message if host has children, or any of the
      # following are present on the host
      #   DNS servers, repositories

      $devinfo = $this->Host->NetDevice->findAllByHostId($id,'','','','',1);

      // "Cake Way" of doing a JOIN is *beyond* me.  just do the f'ing SQL
      $query = $this->{$this->modelClass}->query ("SELECT resource_sets.id FROM resource_sets
       JOIN set_members ON set_members.resource_set_id=resource_sets.id
       WHERE foreign_key=$id AND resource_sets.scope_id=".$this->currentUser['User']['scope_id']."
       AND table_name=\"hosts\" AND set_name IS NULL;");
      $resource_id = empty($query) ? null : $query[0]['resource_sets']['id'];

//TBD get BEGIN TRANSACTION working
//      $ds = $this->getDataSource($this);
//      $ds->begin($this);

//$this->log("hostinfo: ".print_r($hostinfo,true));

      # Disconnect ipv4 entries
      foreach ($devinfo as $item) {
        if ($item['Ipv4']['id'] != null) {
	  $this->data['Ipv4']['id'] = $item['Ipv4']['id'];
          $this->data['Ipv4']['net_device_id'] = null;
          if (!$errset && !$this->Host->NetDevice->Ipv4->save ($this->data)) {
            $this->Session->setFlash(__('Problem deassigning ',true).'ipv4'.__(' entry',true));
	    $errset = true;
	  }
 	}
      }
      # Disconnect ipv6 entries
      foreach ($devinfo as $item) {
        if ($item['Ipv6']['id'] != null) {
	  $this->data['Ipv6']['id'] = $item['Ipv6']['id'];
          $this->data['Ipv6']['net_device_id'] = null;
          if (!$errset && !$this->Host->NetDevice->Ipv6->save ($this->data)) {
            $this->Session->setFlash(__('Problem deassigning ',true).'ipv6'.__(' entry',true));
	    $errset = true;
	  }
 	}
      }

      # Now delete related entries in hostfiles, set_members, soft_meta, users_groups

      if (!$errset && !$this->{$this->modelClass}->Hostfile->deleteall(array
	       ('Hostfile.host_id' => $id,
		'Hostfile.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'hostfile'.__(' entries',true));
	  $errset = true;
      }
      if (!$errset && !$this->{$this->modelClass}->NetDevice->deleteall(array
	       ('NetDevice.host_id' => $id,
		'NetDevice.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'net_device'.__(' entries',true));
	  $errset = true;
      }
      if (!$errset && !$this->{$this->modelClass}->UsersGroup->deleteall(array
	       ('UsersGroup.host_id' => $id,
		'UsersGroup.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'users_group'.__(' entries',true));
	  $errset = true;
      }
      if (!$errset && !$this->{$this->modelClass}->SetMember->deleteall(array
	       ('SetMember.table_name' => 'hosts',
	        'SetMember.foreign_key' => $id,
		'SetMember.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'set_member'.__(' entries',true));
	  $errset = true;
      }
      if ($resource_id != null) {
        if (!$errset && !$this->{$this->modelClass}->SetMember->ResourceSet->SetBinding->deleteall(array
	       ('SetBinding.resource_set_id' => $resource_id,
		'SetBinding.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'set_binding'.__(' entry',true));
	  $errset = true;
        }
        if (!$errset && !$this->{$this->modelClass}->SetMember->ResourceSet->SoftMeta->deleteall(array
	       ('SoftMeta.resource_set_id' => $resource_id,
		'SoftMeta.scope_id' => $this->currentUser['User']['scope_id']),
               false,false)) {
          $this->Session->setFlash(__('Problem removing ',true).'soft_meta'.__(' entry',true));
	  $errset = true;
        }

        if (!$errset && !$this->Host->SetMember->ResourceSet->delete($resource_id)) {
          $this->Session->setFlash(__('Problem removing ',true).'resource_set'.__(' entry',true));
	  $errset = true;
        }
      }
      if ($errset) {
//TBD        $ds->rollback($this);
        $this->redirect(array('action' => 'view', $id));
      }
      else {
//        $ds->commit($this);

        # Host record can now be removed
        parent::delete($id);
      }
    }
  }

//////////////////////////////////////////////////////////////////////////////////////

  function comment($id = null) {
    parent::comment($id);
  }

  function beforeFilter () {
    $this->theme = 'ilinux';
    parent::beforeFilter ();
  }
}
?>
