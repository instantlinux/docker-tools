<?php
// $Id: pending_actions_controller.php 208 2011-08-30 02:56:02Z richb $
class PendingActionsController extends AppController {
  var $helpers = array ('Html', 'Form');
  var $name = 'PendingAction';
  var $components = array ('Auth');
  var $view = 'Theme';

  function index() {
    parent::index();
  }
  function view($id = null) {
    parent::view();
  }
  function add() {
    parent::add();
  }
  function edit($id = null) {
    parent::edit($id);
  }
  function delete($id = null) {
    parent::delete($id);
  }

  function run($id = null) {
    $this->{$this->modelClass}->useDbConfig = 'master';
    $scope = $this->currentUser['User']['scope_id'];
    $contain = array ('Action', 'Action.User' => array ('user_name', 'uid'), 'DataCenter');
    if (!$id) {
      $action_codes = $this->PendingAction->find('all', array('conditions' => array 
                 ('PendingAction.scope_id' => $scope,
		  'Action.disabled' => false),
		 'recursive' => 2, 'contain' => $contain,
		 'joins' => array(array('table' => 'actions', 'alias' =>
		     'Action', 'type' => 'inner', 'conditions' => 'Action.id = PendingAction.action_id')),
		 'order' => array ('Action.precedence', 'Action.action_code')));
    }
    else {
      $action_codes = $this->PendingAction->find('all',
        array('conditions' => array('PendingAction.id' => $id,
                 'PendingAction.scope_id' => $scope),
		 'recursive' => 2, 'contain' => $contain));
    }

    // Get list of data centers, if any

    $data_centers = $this->PendingAction->DataCenter->find('all',
        array('fields' => array('data_center', 'inbound_proxy'), 'conditions' => array(
		 'DataCenter.inbound_proxy !=' => '',
                 'DataCenter.scope_id' => $scope),
	      'contain' => array('Meta.data_value', 'Meta.MetaField.parameter_name'), 
	      'recursive' => 2));

    // "Cake way" above causes multiple queries, below is a better query.
    // TBD translate this to Cake
/*  $query = $this->PendingAction->query("SELECT data_centers.id,data_center,inbound_proxy,parameter_name,data_value,
 *      CONCAT('scope-',data_centers.scope_id,'-',data_center,'-',IF(parameter_name='inbound_ssh_key_rsa','rsa','dsa'))
 *      AS file_name
 *	FROM data_centers
 *	JOIN meta ON meta.foreign_key=data_centers.id
 *	JOIN meta_fields ON meta_fields.id=meta.meta_field_id
 *	WHERE data_centers.scope_id=1 AND inbound_proxy !='' AND meta.table_name='data_centers';");
 */
    // TBD deal with this username stuff... requires fiddling with
    //  /etc/sudoers which usually requires a great deal of effort
    //  Also:   implement $action_username in the appropriate place (sudo -u after the ssh)
    // TBD deal with this hardcoded pathname

    // As of 6/29/2011 everything runs as user 'capi' since the ssh keys have
    // to match on both ends
    $hardcoded_username = 'capi';
    $hardcoded_path = '/var/lib/ilinux/actions';

    $result_set = array ();
    $ran_ok = array ();
    $errset = false;
    foreach ($action_codes as $action_code) {
      $actions = array();
      $actions['action_code'] = $action_code['Action']['action_code'];
      $actions['id'] = $action_code['PendingAction']['id'];
      $actions['cmd'] = $actions['action_code'];
   // $action_username = $action_code['Action']['User']['user_name'];
      $cmd = "";

      if (isset($action_code['DataCenter']['inbound_proxy']) &&
          $action_code['DataCenter']['inbound_proxy'] != '')
	 $prepend = "sudo -u $hardcoded_username ssh -l $hardcoded_username -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ".$action_code['DataCenter']['inbound_proxy']." ";
      else if (empty($data_centers))
         $prepend = "sudo -u#".$action_code['Action']['User']['uid'];
      if (isset($prepend)) {
        $output = array();
	$cmd = "$prepend /usr/bin/cap -f $hardcoded_path/capfile ".$actions['cmd']." 2>&1";
        exec ($cmd, &$output, &$actions['retval']);
        $actions['output'] = implode("\n", $output);
      }
      else {
	$actions['retval'] = 0;
        $actions['output'] = "";

	// TBD - right now all actions are sent to the inbound proxy of all data
 	// centers - fix it so actions are limited to a specific center
        foreach ($data_centers as $item) {
	  $tcp_arg = "";
	  $key_type = "";
	  $keyfile_arg = "-i /home/$hardcoded_username/.ssh/proxies/inbound-default";
	  foreach ($item['Meta'] as $field) {
	    switch ($field['MetaField']['parameter_name']) {
	      case 'inbound_ssh_key_rsa': $key_type = 'rsa'; break;
	      case 'inbound_ssh_key_dsa': $key_type = 'dsa'; break;
	      case 'inbound_ssh_port': $tcp_arg = ' -p '.$field['data_value']; break;
	    }
	  }
	  if ($key_type != "")
	    $keyfile_arg = "-i /home/$hardcoded_username/.ssh/proxies/scope-$scope-{$item['DataCenter']['data_center']}-$key_type";
          $output = array();
	  $cmd = "sudo -u $hardcoded_username ssh $keyfile_arg$tcp_arg -l $hardcoded_username -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null {$item['DataCenter']['inbound_proxy']} /usr/bin/cap -f $hardcoded_path/capfile ".
	    $actions['cmd']." 2>&1";
          exec ($cmd, &$output, &$retval);
          $actions['output'] .= implode("\n", $output);
	  if ($retval != 0)
	    $actions['retval'] = $retval;
        }
      }
      if ($actions['retval'] == 0)
            $ran_ok[] = $actions['id'];
      else {
            $errset = true;
	    $this->log(__('Action not completed:',true).' '.$actions['cmd'].__(', result:',true).$actions['output']."\n\t($cmd)");
      }
      $result_set[] = $actions;
    }
    if (!$errset && !empty($ran_ok) && $this->PendingAction->deleteAll(array('id' => $ran_ok), false))
      $this->Session->setFlash('Completed all PendingActions');
    else {
      if ($errset) {
        // Delete those which succeeded
        foreach ($result_set as $action)
	  if ($action['retval'] == 0)
	    $this->PendingAction->delete($action['id']);
        $this->Session->setFlash('Problem completing PendingAction');
      }
    }
    $this->set('result_set', $result_set);
    $this->set('syncNeeded', $this->_syncNeeded ());
  }
  function beforeFilter () {
    	  $this->theme = 'ilinux';
	  parent::beforeFilter ();
  }
}
?>
