<?php
// $Id: i18n_labels_controller.php 166 2011-07-05 00:13:10Z richb $

class I18nLabelsController extends AppController {
  var $helpers = array ('Html', 'Form');
  var $name = 'I18nLabel';
  var $view = 'Theme';

  function index() {
    parent::index();
  }

  function view($id = null) {
    parent::view();
    $this->set('I18nLabel', $this->I18nLabel->find('list', array('conditions' =>
        array('locale' => $this->locale, 'translation !=' => ''), 'fields' => array('I18nLabel.msgid', 'I18nLabel.translation'))));
    $this->set('I18nLabelHelp', $this->_getI18nLabelHelp());
  }

//////////////////////////////////////////////////////////////////////////

  function add($id = null) {
    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master';

      if ($this->data['Label']['msgid'] == '') {
        $this->Session->setFlash('I18nLabel ' . __('Please enter a label msgid', true));
      }
      else {        
        // Build a set of records from the Translate.xxx.translation values
        $this->data['I18nLabel'] = array ();
        foreach ($this->data['Translate'] as $key => $item) {
          if ($item['translation']!='' || $item['help_text']!='') {
	    $this->data['I18nLabel'][$key]['msgid'] = $this->data['Label']['msgid'];
	    $this->data['I18nLabel'][$key]['i18n_lang_id'] = $item['I18nLang']['id'];
	    $this->data['I18nLabel'][$key]['locale'] = $item['I18nLang']['iso639_2'];
	    $this->data['I18nLabel'][$key]['translation'] = $item['translation'];
	    $this->data['I18nLabel'][$key]['help_text'] = $item['help_text'];
            $this->data['I18nLabel'][$key]['scope_id'] = $this->currentUser['User']['scope_id'];
	  }
        }
        if ($this->I18nLabel->saveall($this->data['I18nLabel'], array('validate'=>'first'))) {
          $this->Session->setFlash('I18nLabel ' . __('entry saved', true));
          $this->redirect(array('action' => 'index'));
        }
        else {
          $this->Session->setFlash(__('Could not save', true) . ' I18nLabel ' . __('entry, validation error', true));
        }
      }
    }
    $this->data['Translate'] = $this->I18nLabel->I18nLang->find('all',
	       array('fields' => array('I18nLang.iso639_2', 'I18nLang.english_name','I18nLang.id'), 'conditions' =>
	       array ('disabled' => '0')));
  }

//////////////////////////////////////////////////////////////////////////

  function edit($id = null) {
    $this->I18nLabel->id = $id;
    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master';

      $errset = false;
      // Build a set of records from the Translate.xxx.translation values
      $this->data['I18nLabel'] = array ();
      foreach ($this->data['Translate'] as $key => $item) {
        if ($item['translation']!='' || $item['help_text']!='') {
	  $this->data['I18nLabel'][$key]['id'] = $item['I18nLabel']['id'];
	  $this->data['I18nLabel'][$key]['msgid'] = $this->data['Label']['msgid'];
	  $this->data['I18nLabel'][$key]['i18n_lang_id'] = $item['I18nLang']['id'];
	  $this->data['I18nLabel'][$key]['locale'] = $item['I18nLang']['iso639_2'];
	  $this->data['I18nLabel'][$key]['translation'] = $item['translation'];
	  $this->data['I18nLabel'][$key]['help_text'] = $item['help_text'];
          $this->data['I18nLabel'][$key]['scope_id'] = $this->currentUser['User']['scope_id'];
	}
	else if ($item['I18nLabel']['id'] != '') {
          if (!$this->I18nLabel->delete($item['I18nLabel']['id'])) {
            $this->Session->setFlash(__('Problem removing I18nLang entry',true));
            $errset = true;
          }
	  else
	    unset($this->data['Translate'][$key]);
	}
      }
      if (!$errset && $this->I18nLabel->saveall($this->data['I18nLabel'])) {
        $this->Session->setFlash('I18nLabel entry updated');
        $this->redirect(array('action' => 'index'));
      }
      else {
        $this->Session->setFlash('I18nLabel ' . __('entry has errors', true));
      }
    }
    $this->data['Translate'] = $this->I18nLabel->I18nLang->find('all',
	       array('fields' => array('I18nLang.iso639_2', 'I18nLang.english_name','I18nLang.id'), 'conditions' =>
	       array ('disabled' => '0'), 'recursive' => 0));
    $query = $this->I18nLabel->read();
    $this->data['Label']['msgid'] = $query['I18nLabel']['msgid'];
    $query = $this->I18nLabel->findAllbyMsgid($query['I18nLabel']['msgid']);

    // TBD: this requires an inefficient array search due to lack of a keyed
    //  findAll function which would providing indexing by record ID instead
    //  of a sequential 0 to n list
    $lang_ids = array();
    foreach ($this->data['Translate'] as $key => $item)
      $lang_ids[$key] = $item['I18nLang']['id'];

    foreach ($query as $item) {
      $key = array_search($item['I18nLang']['id'], $lang_ids);
      $this->data['Translate'][$key]['I18nLabel'] = $item['I18nLabel'];
      $this->data['Translate'][$key]['translation'] = $item['I18nLabel']['translation'];
      $this->data['Translate'][$key]['help_text'] = $item['I18nLabel']['help_text'];
    }
  }

//////////////////////////////////////////////////////////////////////////

  function delete($id = null) {
    parent::delete($id);
  }
  function comment($id = null) {
    parent::comment($id);
  }
  function beforeFilter () {
	$this->theme = 'ilinux';

	parent::beforeFilter ();
  }
}
?>
