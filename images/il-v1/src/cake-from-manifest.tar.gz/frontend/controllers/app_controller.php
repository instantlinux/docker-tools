<?php
// $Id: app_controller.php 232 2011-10-21 19:06:48Z richb $
// Created 2/7/2011 by richb

// Functions
//    index
//    view
//    add
//    edit
//    delete
//    comment
//    ajaxauto
//    beforeFilter
//    beforeRender
//    _getDropDown
//    _getI18nLabels
//    _getI18nLabelHelp
//    _getComments
//    _syncNeeded

require_once 'libs/common.php';

class AppController extends Controller {
  var $components = array ('DebugKit.Toolbar', 'SessionAcl', 'RequestHandler',
   'Security', 'Session',
   'Auth' => array ( 'authorize' => 'actions', 'actionPath' => 'controllers/',
     'fields' => array('username' => 'user_name', 'password' => 'md5passwd'),
     'loginAction' => array('controller' => 'users', 'action' => 'login'),
     'logoutRedirect' => array('controller' => 'users', 'action' => 'login'),
     'userScope' => array('User.disabled' => 0, 'User.locked' => 0))
  );

  function index() {
    $pagerow_limit = ($this->params['url']['ext'] == 'xml' ||
                      $this->params['url']['ext'] == 'json') ? 99999 : 25;
    $recursive = 0;

    // Pick up any params passed from the URL, strip out the "page:n"
    // and sort params, and feed rest to the paginator
    $urlParams = $this->params['named'];
    unset($urlParams['page']);
    unset($urlParams['sort']);
    unset($urlParams['direction']);

    $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], null, null);

    // Explicitly query just the fields we need from related tables
    $contain = array();
    $conditions = array();
    $fields = array ('id');

#    $this->{$this->modelClass}->Behaviors->attach("Containable",array("recursive"=>true));

    $hasCakeVirtual = false;
    foreach ($this->data['workObject']['Attrs'] as $key => $attr) {
      if (isset($attr['fktable'])) {
        foreach ($attr['options']['fkfield'] as $field) {
	  if (isset($attr['habtm']))
	    $contain[] = Inflector::classify($attr['habtm']).'.'.
	                 Inflector::classify($attr['fktable']).'.'.$field;
	  else if ($attr['fktable'] != $this->data['workObject']['tableName'])
            $contain[] = $this->{$this->modelClass}->modelFromTable($attr['fktable']).'.'.$field;
 	}

	// IL-275 in progress
	// Check to see if the linked fkfield is a CakePHP-defined virtualField (see IL-181)
	// After making a schema change, if isVirtualField function gets this error
	//   "Fatal error: Call to a member function isVirtualField() on a non-object"
	// check the hasMany/belongsTo table relatinships!
	
        if (!isset($attr['habtm']) && (($attr['fktable'] != $this->data['workObject']['tableName'] &&
	    $this->{$this->modelClass}->{$this->{$this->modelClass}->modelFromTable($attr['fktable'])}->
              isVirtualField($attr['options']['fkfield'][0]))
              ||
	    ($attr['fktable'] == $this->data['workObject']['tableName'] &&
	    $this->{$this->modelClass}->
                isVirtualField($attr['options']['fkfield'][0]))))
          $hasCakeVirtual = true;
      }

      // If the field has any values specified as omit_index, add to $conditions
      if (isset($attr['options']['index_omit']))
	$conditions['NOT'][$key] = $attr['options']['index_omit'];

      // Also build a list of non-meta/multiselect/virtual fields from the workObject
      if (!isset($attr['meta_field_id']) && !isset($attr['virtual']) &&
          $attr['field_type_id'] != FTYPE_SELECT_MULTI)
        $fields[] = $key;
    }
    if (isset($this->data['workObject']['canPersist']))
      $fields[] = 'persistent';

    // Any reference to a Cake-defined virtual field forces us to abandon
    //  predefined field list
    if ($hasCakeVirtual)
      $fields = null;

    // TBD: figure out where to put these special cases
    switch ($this->modelClass) {
      case 'Host':
        $recursive = 1;  // TBD only needed for roles/domain: remove if too inefficient
        $contain[] = 'Location.lft';
        $contain[] = 'Location.rght';
        $contain[] = 'NetDevice.domain';
	break;
      case 'IsoImage':
        // Above logic to pick up hasCakeVirtual doesn't yet work so null out $fields
	$fields = null;
	break;
      case 'Meta':
      case 'SoftMeta':
        $contain[] = 'MetaField.field_type_id';
        $contain[] = 'MetaField.options';
	break;
      case 'NetDevice':
        $contain[] = 'Ipv4.ip_address';
        $contain[] = 'Ipv6.ipv6_address';
        // Next line is to deal with error 1054: Unknown column 'Subnet.network'
        //   which is a virtual field in a related model.  TBD figure this out.
        $fields = null;
	break;
      case 'PendingAction':
        $fields[] = 'created';
        $fields[] = 'creator';
	break;
      case 'ResourceSet':
	$recursive = 1;
	$fields = null;
	$contain = array();
	$contain[] = 'SetMember.Host';
	$contain[] = 'SetBinding.Swmodule';
	$contain[] = 'SetBinding.Action';
	$contain[] = 'SetBinding.Repository';
	break;
      case 'User':
	$recursive = 1;
	$contain[] = 'UsersGroup.group_id';
	$contain[] = 'UsersGroup.Group.group_name';
	break;
    }
//IL-275 $this->log("fields: ".print_r($fields,true));
//$this->log("contain: ".print_r($contain,true));
    // Don't show any records outside logged-in scope
    if (isset($this->{$this->modelClass}->belongsTo['Scope']))

    $urlParams[$this->modelClass.'.scope_id'] = $this->currentUser['User']['scope_id'];
    $details = false;
    if (isset($urlParams['details'])) {
      $details = $urlParams['details'] == 'true';
      unset($urlParams['details']);
    }

    $this->paginate = array ('conditions' => array_merge($urlParams, $conditions), 'limit' => $pagerow_limit,
  	     'contain' => $contain, 'fields' => $fields, 'recursive' => $recursive);
    $this->set($this->modelClass, $this->paginate($this->modelClass));
    if ($this->params['url']['ext'] == 'xml' || $this->params['url']['ext'] == 'json')
     $this->set('xmlBrief', $this->{$this->modelClass}->getXMLbrief ($this->currentUser['User']['scope_id'],
  	     $this->currentUser, $this->data['workObject'], $urlParams, null, $details));
  }

//////////////////////////////////////////////////////////////////////////

  function view($id = null) {
    $recursive = 1;
    $contain = null;
    $scope_id = isset($this->currentUser) ? $this->currentUser['User']['scope_id'] : 1;

    // TBD figure out where to store these fields
    switch ($this->modelClass) {
      case 'DnsServer':
        $contain = array();
	$contain[] = 'Domain.domain_name';
	$contain[] = 'NetDevice.fqdn_dev';
	break;
      case 'Host': $recursive = 2;
        $contain = array();
	$contain[] = 'DistroRev.Distro';
	$contain[] = 'Group.group_name';
	$contain[] = 'HostType.host_type';
	$contain[] = 'ModelNum.model_num';
	$contain[] = 'ModelNum.vendor_name';
	$contain[] = 'ModelNum.Vendor';
	$contain[] = 'Location';
	$contain[] = 'NetDevice';
	$contain[] = 'NetDevice.Domain';
	$contain[] = 'NetDevice.Ipv4';
	$contain[] = 'SetMember';
	$contain[] = 'SetMember.ResourceSet';
	$contain[] = 'SetMember.ResourceSet.SetBinding';
	$contain[] = 'Children.hostname';
	$contain[] = 'Children.id';
	$contain[] = 'Children.created';
	$contain[] = 'History';
	$contain[] = 'Meta';
	$contain[] = 'Comment';
        break;
      case 'PackageDep':
        $contain = array();
	$contain[] = 'Distro';
	$contain[] = 'DistroRev.version_no';
	$contain[] = 'Package';
	$contain[] = 'Swmodule';
	break;
      case 'ResourceSet': $recursive = 2;
        $contain = array();
	$contain[] = 'SetMember.Host';
	$contain[] = 'SetBinding.Swmodule';
	$contain[] = 'SetBinding.Action';
	$contain[] = 'SetBinding.Repository';
	$contain[] = 'History';
	$contain[] = 'Comment';
        break;
      case 'User': $recursive = 2;
        $contain = array();
	$contain[] = 'Group.group_name';
	$contain[] = 'UsersGroup.Group.group_name';
	$contain[] = 'History';
	break;
    }
    $urlParams = $this->params['named'];
    $details = false;
    $related = false;
    if ($id) {
      // Integer id already specified:  read it
      if (!$query = Cache::read("view-$scope_id-".$this->modelClass."-$id")) {
        $conditions = array($this->modelClass.'.id' => $id);
	if (isset($this->{$this->modelClass}->belongsTo['Scope']))
	  $conditions[$this->modelClass.'.scope_id'] = $scope_id;
	if (!$query = $this->{$this->modelClass}->find('first', array(
          'conditions' => $conditions,
          'contain' => $contain, 'recursive' => $recursive))) {
	  $this->Session->setFlash(__('Invalid id for', true) . ' ' . $this->modelClass);
	  $this->log("view failed(".$this->modelClass.".$id)");
	  // TBD redirect correctly
	  return null;
	}
	Cache::write("view-$scope_id-".$this->modelClass."-$id", $query, 'short');
      }
      if (isset($urlParams['details']))
        $details = $urlParams['details'] == 'true';
      if (isset($urlParams['related']))
        $related = $urlParams['related'] == 'true';
      $this->{$this->modelClass}->id = $id;
      $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, $query);
    }
    else {
      // Else find the first in-scope match based on field(s) specified in URL
      $urlParams[$this->modelClass.'.scope_id'] = $scope_id;
      if ($this->modelClass == 'StaticPage')
	$urlParams['I18nLang.iso639_2'] = $this->locale;
      if (isset($urlParams['details'])) {
        $details = $urlParams['details'] == 'true';
	unset($urlParams['details']);
      }
      if (isset($urlParams['related'])) {
        $related = $urlParams['related'] == 'true';
	unset($urlParams['related']);
      }
      $query = $this->{$this->modelClass}->find('first',
         array ('conditions' => $urlParams, 'contain' => $contain, 'recursive' => $recursive));
      $id = $query[$this->modelClass]['id'];
      $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, $query);
    }

    $this->set('Comment', $this->_getComments($scope_id, $id));
    if ($this->params['url']['ext'] == 'xml' || $this->params['url']['ext'] == 'json')
      $this->set('xmlBrief', $this->{$this->modelClass}->getXMLbrief($this->currentUser['User']['scope_id'],
         $this->currentUser, $this->data['workObject'], null, $id, $details, $related));
  }

//////////////////////////////////////////////////////////////////////////

  function add($redir = true) {
    $auth = $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);
    if (!$auth['Actions']['add'])
      $this->redirect(array('action' => 'index'));

    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master';
      $this->{$this->modelClass}->History->useDbConfig = 'master';
      $this->{$this->modelClass}->Meta->useDbConfig = 'master';
      if ($this->modelClass == 'User' || $this->modelClass == 'Group') {
	$this->loadModel('Aro');
	$this->Aro->useDbConfig = 'master';
      }
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      if ($key = array_search('Tree', $this->{$this->modelClass}->actsAs)) {
         unset($this->{$this->modelClass}->actsAs[$key]); 
         $this->{$this->modelClass}->Behaviors->attach("Tree", array('scope' =>
            'scope_id='.$this->currentUser['User']['scope_id']));
      }

      $errset = false;

      // Fetch object attributes (from cache)
      $cached = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], null, null);
      if (empty($cached)) {
        $this->Session->setFlash(__('Object went away, could identify attributes', true));
        $errset = true;
      }
      if (isset($this->{$this->modelClass}->hasMany['History'])) {
        $history = array ();
        $history['action'] = 'add';
        $history['creator'] = $this->currentUser['User']['user_name'];
        $history['scope_id'] = $this->currentUser['User']['scope_id'];
        $history['table_name'] = $this->{$this->modelClass}->table;
        $this->data['History'][] = $history;
      }
      if (!$errset) {
        $this->data['Meta'] = array();
        $meta = array ();
        $meta['table_name'] = $this->{$this->modelClass}->table;
	$meta['scope_id'] = $this->currentUser['User']['scope_id'];
	$bool_model_loaded = false;

        foreach ($cached['Attrs'] as $field => $attr) {
	  if (!isset($attr['meta_field_id'])) {
           // TBD 5/30/2011 - move the hosts_controller for swmodule bindings here
           if ($field != 'module_bindings' || $this->modelClass != 'Host') {
	    if ($attr['field_type_id'] == FTYPE_SELECT_MULTI) {
	      // Multi-select:  generate records for each selected item
      	      $attrs = $this->data['workObject']['Attrs'];
      	      $model = Inflector::classify($attr['habtm']);
	      $this->{$this->modelClass}->{$model}->useDbConfig = 'master';
      	      if (!isset($this->data[$model]))
	        $this->data[$model] = array();
	      $fkfield = $this->{$this->modelClass}->{$model}->belongsTo[Inflector::classify($attr['fktable'])]['foreignKey'];
	      switch ($attr['habtm']) {
	        case 'set_members':
		case 'set_bindings':
		  // TBD deal with this special-case for hosts controller
		  if ($attr['fktable'] == 'resource_sets')
		    $table_name = 'hosts';
		  else
		    $table_name = $attr['fktable'];
		  break;
		default:
		  unset ($table_name);
	      }

      	      if (!empty($attrs[$field]['data_value'])) {
                foreach ($attrs[$field]['data_value'] as $key => $item) {
          	  $this->data[$model][$key][$fkfield] = $item;
	  	  $this->data[$model][$key]['scope_id'] = $this->currentUser['User']['scope_id'];
		  if (isset($table_name))
          	    $this->data[$model][$key]['table_name'] = $table_name;
		}
	      }
      	      if (empty($this->data[$model]))
	        unset($this->data[$model]);
	    }
	    else 
	      $this->data[$this->modelClass][$field] =
	           $this->data['workObject']['Attrs'][$field]['data_value'];
           // end TMP 5/30
           }
	  }
	  else {
	    // Meta fields:
	    // If changed from default, add entry to $this->data['Meta'] for saving

	    $defval = isset($attr['default_value']) ? $attr['default_value'] : '';
	    $newval = $this->data['workObject']['Attrs'][$field]['data_value'];
	    if ($newval != $defval) {
	      $meta['meta_field_id'] = $attr['meta_field_id'];

	      if ($attr['field_type_id'] != FTYPE_BOOLEAN || !isset($attr['bool_style']))
		  $meta['data_value'] = $newval;
	      else {
		// True/false values come in varieties that are stored in
		// the boolean_values table.  Use this table to look up the
		// value to be stored.
		  
		if (!$bool_model_loaded) {
		    $this->loadModel('BooleanValue');
		    $bool_model_loaded = true;
		}
		$query = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('bool_style' => $attr['bool_style']), 'recursive' => -1));
		if (empty($query))
		    $meta['data_value'] = $newval;
		else
		    $meta['data_value'] = $newval ? $query['BooleanValue']['true'] : $query['BooleanValue']['false'];
	      }
	      $this->data['Meta'][] = $meta;
	    }
	  }
	}
        if (empty($this->data['Meta']))
          unset($this->data['Meta']);
      }

      // Null out or clean up certain fields
      if ($this->modelClass == 'Domain' && $this->data[$this->modelClass]['domain'] == '')
        $this->data[$this->modelClass]['domain'] = null;
      else if ($this->modelClass == 'Subnet' && $this->data[$this->modelClass]['network_ipv4'] == '')
        $this->data[$this->modelClass]['network_ipv4'] = null;
      else if ($this->modelClass == 'Subnet' && $this->data[$this->modelClass]['network_ipv6'] == '')
        $this->data[$this->modelClass]['network_ipv6'] = null;

      // Save the data including history/meta
      if (!$errset) {
        if (isset($cached['validate']))
          $this->{$this->modelClass}->validate = $cached['validate'];
	$this->data[$this->modelClass]['scope_id'] = $this->currentUser['User']['scope_id'];
	$this->data[$this->modelClass]['creator'] = $this->currentUser['User']['user_name'];
//$this->log('AppController::add: '.print_r($this->data, true));
        if ($this->{$this->modelClass}->saveall($this->data)) {
          $this->Session->setFlash($this->modelClass . ' '. __('entry saved', true));
	  Cache::delete("keylist-".$this->currentUser['User']['scope_id']."-".$this->{$this->modelClass}->table);
	  if ($redir)
            $this->redirect(array('action' => 'index'));
        }
        else {
	  $this->Session->setFlash(__('Could not save', true) . ' '.$this->modelClass.' ' . __('entry, validation error', true). ', fields: ' . implode(", ", array_keys($this->{$this->modelClass}->invalidFields())));
	}
      }
    }

    $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], null, null);

    // Populate the drop-down fields for foreign-key relationships
    $this->_getDropDown();

    // Apply any default values
    foreach ($this->data['workObject']['Attrs'] as $field => $attr)
      if (isset($attr['default_value']))
        $this->data['workObject']['Attrs'][$field]['data_value'] = $attr['default_value'];

    // Static pages have two special defaults
    if ($this->modelClass == 'StaticPage') {
      $this->loadModel('I18nLang');
      $query = $this->I18nLang->find('first', array('conditions' =>
           array('iso639_2' => $this->locale), 'recursive' => -1));
      $this->data['workObject']['Attrs']['i18n_lang_id']['default_value'] = $query['I18nLang']['id'];
      $this->data['workObject']['Attrs']['user_id']['default_value'] = $this->currentUser['User']['id'];
    }
  }

//////////////////////////////////////////////////////////////////////////

  function edit($id = null, $redir = true) {
    $auth = $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);
    if (!$auth['Actions']['edit'])
      $this->redirect(array('action' => 'index'));

    $this->{$this->modelClass}->id = $id;

    if (!empty($this->data)) {
      $this->{$this->modelClass}->useDbConfig = 'master';
      $this->{$this->modelClass}->History->useDbConfig = 'master';
      $this->{$this->modelClass}->Meta->useDbConfig = 'master';
      if ($this->modelClass == 'User' || $this->modelClass == 'Group') {
	$this->loadModel('Aro');
	$this->Aro->useDbConfig = 'master';
      }
      $this->{$this->modelClass}->currentUser = $this->currentUser;
      if ($key = array_search('Tree', $this->{$this->modelClass}->actsAs)) {
         unset($this->{$this->modelClass}->actsAs[$key]); 
         $this->{$this->modelClass}->Behaviors->attach("Tree", array('scope' =>
            'scope_id='.$this->currentUser['User']['scope_id']));
      }

      $errset = false;

      // Fetch old values (from cache)

//TBD: need to make sure habtm data is fetched at recursion level 1

      $cached = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, null);
      if ($id=='' || empty($cached)) {
        $this->Session->setFlash(__('Object went away, could not edit', true));
        $errset = true;
      }
      $history = array ();
      $history['creator'] = $this->currentUser['User']['user_name'];
      $history['scope_id'] = $this->currentUser['User']['scope_id'];
      $history['table_name'] = $this->{$this->modelClass}->table;
      $history['foreign_key'] = $id;
      $meta = array ();
      $meta['table_name'] = $this->{$this->modelClass}->table;
      $meta['foreign_key'] = $id;
      $meta['scope_id'] = $this->currentUser['User']['scope_id'];
      $this->data['History'] = array();
      $this->data[$this->modelClass] = array();
      $bool_model_loaded = false;

      // Compare new and cached values for each field

      if (!$errset) {
        foreach ($cached['Attrs'] as $field => $oldattr) {
	  if (!isset($oldattr['meta_field_id'])) {
           // TBD 5/30/2011 - move the hosts_controller for swmodule bindings here
           if ($field != 'module_bindings' || $this->modelClass != 'Host') {
	    if ($oldattr['field_type_id'] == FTYPE_SELECT_MULTI) {
	      // Multi-select:  generate records for each selected item
      	      $attrs = $this->data['workObject']['Attrs'];
      	      $model = Inflector::classify($oldattr['habtm']);
	      $this->{$this->modelClass}->{$model}->useDbConfig = 'master';
      	      if (!isset($this->data[$model]))
	        $this->data[$model] = array();
	      $fkfield = $this->{$this->modelClass}->{$model}->belongsTo[Inflector::classify($oldattr['fktable'])]['foreignKey'];
	      switch ($oldattr['habtm']) {
	        case 'set_members':
		case 'set_bindings':
		  $DELfield = $this->{$this->modelClass}->{$model}->belongsTo[$this->modelClass]['foreignKey'];
		  // TBD deal with this special-case for hosts controller
		  if ($oldattr['fktable'] == 'resource_sets') {
		    $table_name = 'hosts';
		    // Need to preserve membership in this host's null-named resource set
		    $query = $this->{$this->modelClass}->query ("SELECT resource_sets.id FROM
		            resource_sets JOIN set_members ON set_members.resource_set_id=resource_sets.id
			    WHERE foreign_key=$id AND table_name=\"hosts\" AND set_name is null;");
		    if (!empty($query)) {
		      $resource_id = $query[0]['resource_sets']['id'];
	              $conditions = array ($model.'.'.$DELfield => $id,
	                $model.'.'.'scope_id' => $this->currentUser['User']['scope_id'],
		        $model.'.'.'resource_set_id !=' => $resource_id,
		        $model.'.'.'table_name' => $table_name);
		    }
		    else {
		      $this->log("Data integrity error found, missing resource_set for host $id");
		      $errset = true;
		    }
		  }
		  else {
		    $table_name = $oldattr['fktable'];
	            $conditions = array ($model.'.'.$DELfield => $id,
	              $model.'.'.'scope_id' => $this->currentUser['User']['scope_id'],
		      $model.'.'.'table_name' => $table_name);
		  }
		  break;
		case 'users_groups':
		  unset ($table_name);
		  # TBD 9/8/2011 verify the deleteall after this is working.  It does not seem to be.
	          $conditions = array ($model.'.'.$fkfield => $id,
	            $model.'.'.'scope_id' => $this->currentUser['User']['scope_id'],
		    'UsersGroup.host_id' => null);
		  break;
		default:
		  unset ($table_name);
	          $conditions = array ($model.'.'.$fkfield => $id,
	            $model.'.'.'scope_id' => $this->currentUser['User']['scope_id']);
	      }
	      // First, flush all entries for this host from the habtm table

	      if (!$errset && !$this->{$this->modelClass}->{$model}->deleteall($conditions,
  		  false, false)) {
		$this->Session->setFlash(__('Problem purging users_groups',true));
		$errset = true;
	      }

      	      if (!empty($attrs[$field]['data_value'])) {
                foreach ($attrs[$field]['data_value'] as $key => $item) {
		  $record = array($fkfield => $item, 'scope_id' => $this->currentUser['User']['scope_id']);
		  if (isset($table_name))
		    $record['table_name'] = $table_name;
        	  $this->data[$model][] = $record;
		}
	      }
      	      if (empty($this->data[$model]))
	        unset($this->data[$model]);
	    }
	    else if (isset($this->data['workObject']['Attrs'][$field])) {
	      $oldval = isset($oldattr['data_value']) ? $oldattr['data_value'] : '';
	      $newval = $this->data['workObject']['Attrs'][$field]['data_value'];
	      if ($newval != $oldval) {
	        $this->data[$this->modelClass][$field] = $newval;
	        // Add a history entry
	        $history['field_name'] = $field;
	        $history['previous_value'] = $oldval;
		$history['field_type_id'] = $oldattr['field_type_id'];
if (is_array($newval))
  $history['new_value'] = 'TBD IL-102';
else
	        $history['new_value'] = $newval;

	        $this->data['History'][] = $history;
	      }
	    }
           // end TMP 5/30
           }
	  }
	  else {
	    // Meta fields:
	    // If changed to default, delete from meta table
	    // If changed from default, add entry to $this->data['Meta'] for saving

	    $defval = isset($oldattr['default_value']) ? $oldattr['default_value'] : '';
	    if ($oldattr['field_type_id'] == FTYPE_RESTRICTED ||
	        $oldattr['field_type_id'] == FTYPE_ARRAY_RESTRICTED)
	      $oldval = '';
	    else
	      $oldval = isset($oldattr['data_value']) ? $oldattr['data_value'] : $defval;
	    $newval = $this->data['workObject']['Attrs'][$field]['data_value'];
	    if ($newval != $oldval) {
	      if ($newval == $defval) {
	        // Default value selected: delete if present in meta table
	        if (isset ($oldattr['meta_id']) && $oldattr['meta_id'] != '') {
                  if (!$this->{$this->modelClass}->Meta->delete($oldattr['meta_id'])) {
                    $this->Session->setFlash(__('Problem removing meta entry', true));
                    $errset = true;
                  }
		}
	      }
	      else {
	        // Not default: add a meta entry to the stack for saving

	        if (isset($oldattr['meta_id']) && $oldattr['meta_id'] != '')
		  $meta['id'] = $oldattr['meta_id'];
		else if (isset($meta['id']))
		  unset ($meta['id']);
		$meta['meta_field_id'] = $oldattr['meta_field_id'];
		if ($oldattr['field_type_id'] != FTYPE_BOOLEAN || !isset($oldattr['bool_style']))
		  $meta['data_value'] = $newval;
		else {
		  // True/false values come in varieties that are stored in
		  // the boolean_values table.  Use this table to look up the
		  // value to be stored.
		  
		  if (!$bool_model_loaded) {
		    $this->loadModel('BooleanValue');
		    $bool_model_loaded = true;
		  }
		  $query = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('bool_style' => $oldattr['bool_style']), 'recursive' => -1));
		  if (empty($query))
		    $meta['data_value'] = $newval;
		  else
		    $meta['data_value'] = $newval ? $query['BooleanValue']['true'] : $query['BooleanValue']['false'];
		}
		$this->data['Meta'][] = $meta;

		// Also add it to the fields list for validation
		$this->data[$this->modelClass][$field] = $newval;
	      }

	      // Add a history entry
	      $history['field_name']     = $field;
	      $history['previous_value'] = $oldval;
	      $history['new_value']      = $newval;
	      $history['field_type_id']  = $oldattr['field_type_id'];
	      $this->data['History'][] = $history;
            }
	    unset ($this->data[$this->modelClass][$field]);
          }
	}
        if (empty($this->data['Meta']))
          unset($this->data['Meta']);
      }

      if (empty($this->data['History']))
	unset($this->data['History']);

      $this->data[$this->modelClass]['id'] = $id;

      // Null out or clean up certain fields
      if ($this->modelClass == 'Domain' && isset($this->data[$this->modelClass]['domain'])
         && $this->data[$this->modelClass]['domain'] == '')
        $this->data[$this->modelClass]['domain'] = null;
      if ($this->modelClass == 'Subnet' && isset($this->data[$this->modelClass]['network_ipv4'])
        && $this->data[$this->modelClass]['network_ipv4']  == '')
        $this->data[$this->modelClass]['network_ipv4'] = null;
      if ($this->modelClass == 'Subnet' && isset($this->data[$this->modelClass]['network_ipv6'])
        && $this->data[$this->modelClass]['network_ipv6']  == '')
        $this->data[$this->modelClass]['network_ipv6'] = null;

      // Finally, time to save the data itself, including history/meta
      if (!$errset) {
        if (isset($cached['validate']))
          $this->{$this->modelClass}->validate = $cached['validate'];
//$this->log('update: '.print_r($this->data, true));
        if ($this->{$this->modelClass}->saveall($this->data)) {
          $this->Session->setFlash($this->modelClass . ' '. __('entry updated', true));
	  $this->{$this->modelClass}->delWorkObject($this->currentUser['User']['scope_id'], $id);
	  if ($redir)
            $this->redirect(array('action' => 'index'));
	  else
	    return;
        }
        else {
          $this->Session->setFlash($this->modelClass.' ' . __('entry has errors', true). __(', fields: ', true) .
	      implode(", ", array_keys($this->{$this->modelClass}->invalidFields())));
	}
      }
    }

    $this->data['workObject'] = $this->{$this->modelClass}->getWorkObject($this->currentUser['User']['scope_id'], $id, null);
    if (empty($this->data['workObject'])) {
      $this->Session->setFlash(__('Invalid id for', true) . ' '.__($this->modelClass, true));
      $this->redirect(array('action' => 'index'));
    }      
    $this->_getDropDown();

    // Apply any default values; clear any restricted ones
    foreach ($this->data['workObject']['Attrs'] as $field => $attr) {
      if ($attr['field_type_id'] == FTYPE_RESTRICTED || $attr['field_type_id'] == FTYPE_ARRAY_RESTRICTED)
        unset($this->data['workObject']['Attrs'][$field]['data_value']);
      if (isset($attr['default_value']) && !isset($attr['data_value']))
        $this->data['workObject']['Attrs'][$field]['data_value'] = $attr['default_value'];
    }

    if (isset($this->data['workObject']['enableAutocomplete']))
      $this->set('enableAutocomplete', true);
  }

//////////////////////////////////////////////////////////////////////////

  function delete($id = null) {
    $auth = $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);
    if (!$auth['Actions']['delete'])
      $this->redirect(array('action' => 'index'));

    if (!$id) {
      $this->Session->setFlash(__('Invalid id for', true) . ' '.__($this->modelClass, true));
      $this->redirect(array('action' => 'index'));
    }
    else {
      // This 'switch' statement disconnects models that contain virtualFields
      //  that would otherwise generate SQL with ambiguous column references
      switch ($this->modelClass) {
        case 'DnsServer':
	  unset($this->{$this->modelClass}->belongsTo['NetDevice']);
	  break;
	case 'PackageDep':
	  unset($this->{$this->modelClass}->belongsTo['DistroRev']);
	  break;
      }
      // This next 'switch' sets up a list of related models whose linked records must
      // also be deleted
      switch ($this->modelClass) {
        case 'ResourceSet':
	  $related_models = array('SetMember' => 'resource_set_id',
             'SetBinding' => 'resource_set_id', 'SoftMeta' => 'resource_set_id',
	     'Meta' => 'foreign_key');
	  break;
	default:
	  $related_models = array();
	  if (isset($this->{$this->modelClass}->hasMany['Meta']))
	    $related_models['Meta'] = 'foreign_key';
      }

      $scope = $this->currentUser['User']['scope_id'];
      if (isset($this->{$this->modelClass}->belongsTo['Scope']) &&
          !$this->{$this->modelClass}->find('first', array('conditions' =>
             array($this->modelClass.'.id' => $id,
	     $this->modelClass.'.scope_id' => $scope)))) {
        $this->Session->setFlash(__('Invalid id for', true) . ' '.__($this->modelClass, true));
        $this->redirect(array('action' => 'index'));
      }
      $this->{$this->modelClass}->useDbConfig = 'master';
      $this->{$this->modelClass}->History->useDbConfig = 'master';
      if ($this->modelClass == 'User' || $this->modelClass == 'Group') {
	$this->loadModel('Aro');
	$this->Aro->useDbConfig = 'master';
      }
      $this->{$this->modelClass}->currentUser = $this->currentUser;

      if ($key = array_search('Tree', $this->{$this->modelClass}->actsAs)) {
         unset($this->{$this->modelClass}->actsAs[$key]); 
         $this->{$this->modelClass}->Behaviors->attach("Tree", array('scope' => "scope_id=$scope"));
      }

      // TBD need to set up a BEGIN TRANSACTION

      $errset = false;
      // Remove records in related models
      foreach ($related_models as $model => $fk) {
        $this->{$this->modelClass}->$model->useDbConfig = 'master';
        $conditions = array("$model.$fk" => $id, "$model.scope_id" => $scope);
	if ($fk == 'foreign_key')
	  $conditions["$model.table_name"] = $this->{$this->modelClass}->table;
        if (!$errset && !$this->{$this->modelClass}->{$model}->deleteall($conditions,
               false,false)) {
            $this->Session->setFlash(__('Problem removing ',true).$model.__(' entries',true));
	    $errset = true;
	}
      }

      if (!$errset && isset($this->{$this->modelClass}->hasMany['History'])) {
        $history = array (
	  'action'      => 'delete',
          'creator'     => $this->currentUser['User']['user_name'],
	  'scope_id'    => $scope,
          'foreign_key' => $id,
          'table_name'  => $this->{$this->modelClass}->table);
	$this->{$this->modelClass}->History->save($history);
      }

      if (!$errset && $this->{$this->modelClass}->delete($id)) {
        $this->Session->setFlash(__($this->modelClass,true).' ' . __('entry removed', true));
	$this->{$this->modelClass}->delWorkObject($this->currentUser['User']['scope_id'], $id);
        $this->redirect(array('action' => 'index'));
      }
      else {
        $this->Session->setFlash(__('Problem deleting', true) . ' '.__($this->modelClass,true).' '. __('entry', true));
        $this->redirect(array('action' => 'view', $id));
      }
    }
  }

//////////////////////////////////////////////////////////////////////////

  function comment($id) {
    if (!$id) {
      $this->Session->setFlash(__('Invalid id for', true) . ' ' . $this->modelClass);
         $this->redirect(array('action' => 'index'));
    }
    $this->redirect(array('controller' => 'comments', 'action' => 'add',
        'entity' => $this->{$this->modelClass}->table, 'fid' => $id));
  }

/////////////////////////////////////////////////////////////////////////////////////

  // Support for autocomplete lookups.  Parameter string is field.fktable.fkfield

  function ajaxauto ($field = null) {
    if ($field) {
      $param = explode(".", $field);
      $fieldname = $param[0];
      $fkmodel   = Inflector::classify($param[1]);
      $fkfield   = $param[2];

      $this->set('option_list', $opts = $this->{$this->modelClass}->{$fkmodel}->find('list',
        array('fields' => array($fkmodel.'.'.$fkfield),
	      'recursive' => -1,
	      'conditions' => array(
	       $fkmodel.'.'.$fkfield.' LIKE' => $this->data['workObject']['Attrs'][$fieldname]['data_value'].'%',
	       $fkmodel.'.disabled' => false))));
      $this->render('/user/ajaxoptions');
# $this->log("ajax: fieldname=$fieldname model=$fkmodel fkfield=$fkfield search='".
#   $this->data['workObject']['Attrs'][$fieldname]['data_value'].'%'."'".print_r($opts,true));
    }
    else
      $this->log("ajaxauto called from ".$this-modelClass." without field-name parameter");
  }

//////////////////////////////////////////////////////////////////////////

  function beforeFilter () {
    // Auth/ACL logic to be performed prior to a controller action
      $this->loadModel('Aro');

    if ($this->modelClass == 'User') {
      // TBD fix or replace the curl logic so validatePost can be turned back on
      $this->Security->validatePost = false;

      $uri = ($_SERVER['HTTPS'] == 'on' ? 'https' : 'http') . '://' . $_SERVER['SERVER_NAME'] .
        ($_SERVER['SERVER_PORT'] != 80 && $_SERVER['SERVER_PORT'] != 443 ? ':'.$_SERVER['SERVER_PORT'] : '') .
	$_SERVER['REQUEST_URI'];
      $query = $this->User->Scope->find('first', array('conditions' => array
        ('AccessUrl.access_url' => str_replace("/users/login", "", $uri), 'Scope.disabled' => false,
	 'AccessUrl.disabled' => false),
	'joins' => array (array('table' => 'access_urls', 'alias' => 'AccessUrl', 'type' => 'inner',
              'conditions' => array('AccessUrl.scope_id = Scope.id'))),
	'recursive' => 0));
      if (!empty($query))
        $this->Aro->currentUser['User']['scope_id'] =
          $this->Auth->userScope['User.scope_id'] = $query['Scope']['id'];
      else
        $this->Auth->userScope['User.scope_id'] = null;
    }
    $this->Auth->authError = __('Please log in', true);
    $this->Auth->allow ('ajaxauto');

    $this->Aro->currentUser =
      $this->currentUser = $this->Auth->user();
    $this->Permissions->belongsTo['Aro'] = array('conditions' =>
      'Aro.scope_id = '.$this->currentUser['User']['scope_id']);

    $this->isAuthed = !empty($this->currentUser);
    $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);

    // Get language.  TBD:  is there a clean way to get ISO 639-2 code
    // without this silly lookup table?

    $iso639 = array ('ar' => 'ara', 'bg' => 'bul', 'de' => 'deu', 'en' => 'eng', 'en-us' => 'eng', 'es' => 'spa', 'fr' => 'fra', 'hi' => 'hin', 'it' => 'ita', 'ja' => 'jpn', 'km' => 'khm', 'ko' => 'kor', 'nl' => 'nld', 'pt' => 'por', 'ru' => 'rus', 'sv' => 'swe', 'th' => 'tha', 'tl' => 'tgl', 'vi' => 'vie', 'zh' => 'chi' );

    $lang = Configure::read('Config.language');
    $this->locale = $lang == '' ? 'eng' : $iso639[$lang];

    if ($this->RequestHandler->isAjax()) {
      $this->Security->validatePost = false;
    }
    $this->RequestHandler->setContent('json', 'text/x-json');

    // Turn off debugging if accessed from outside dev testbed or if browser
    // is 'curl'
    if ($this->Session->read('Browser.browser') == 'Default Browser' ||
        substr($_SERVER['REMOTE_ADDR'],0,7) != '192.168' ||
        $_SERVER['SERVER_PORT'] != 443)
      Configure::write('debug', 0);
    phpinfo();
  }

//////////////////////////////////////////////////////////////////////////

  function beforeRender() {
    // This function is called before the view (default.ctp) is generated;
    // code here goes through the controllers to generate an array of
    // ACL permissions.  The variable $authModel will contain entries
    // Controller => true/false based on whether the 'index' permission is
    // granted.


// IL-127 6/16/2011 I think this goes away
//    if ($this->modelClass == 'CakeError')
//      return;
//    $this->_getAuth($this->currentUser['User']['scope_id'], $this->Auth->user(), $this->modelClass);

    $this->set('syncNeeded', $this->_syncNeeded ());

    if ($this->modelClass != 'I18nLabel') {
      $this->set('I18nLabel', $this->_getI18nLabels());
      $this->set('I18nLabelHelp', $this->_getI18nLabelHelp());
    }
    if ($this->RequestHandler->isAjax()) {
        $this->layout = 'ajax';
        Configure::write('debug', 0);
    }

    # TBD 4/19/2011 why does this isXML clause not work?!?
    if ($this->RequestHandler->isXML() 
        || $this->params['url']['ext'] == 'json'
    ) {
      Configure::write('debug', 0);
    }
  } 

//////////////////////////////////////////////////////////////////////////

  // Populate the drop-down fields for foreign-key relationships

  function _getDropDown () {
    $dropDown = array();
    $opt_list_loaded = false;    

    foreach ($this->data['workObject']['Attrs'] as $field => $attr) {
      if (isset($attr['fktable']) && isset($attr['options']['fkfield'])) {
        if (!$list = Cache::read('keylist-'.$this->currentUser['User']['scope_id']."-".$attr['fktable'])) {
	  $model = $this->{$this->modelClass}->modelFromTable($attr['fktable']);

	  // TBD conditions => array ('disabled' => 0)
	  // Set conditions - scoped tables
	  switch ($model) {
	    case 'ResourceSet':
	      $conditions = array ('scope_id' => $this->currentUser['User']['scope_id'],
	      		  'or' => array('set_name !=' => 'default', 'set_name' => null));
	      break;
	    case 'AcosLocal':
	    case 'FieldType':
	    case 'HostType':
	    case 'I18nLang':
	    case 'NetdevType':
	      $conditions = null;
	      break;
	    default:
	      $conditions = array ('scope_id' => $this->currentUser['User']['scope_id']);
	  }
	  if ($model == $this->modelClass)
	    $list = $this->{$model}->find(
	      'list', array('fields' => $field == 'parent_id' ?
	      	  $this->{$this->modelClass}->getPrimaryField() : $attr['options']['fkfield'],
	      'recursive' => -1, 'conditions' => $conditions));
	  else if (isset($attr['habtm']))
	    $list = $this->{$this->modelClass}->{$this->{$this->modelClass}->modelFromTable($attr['habtm'])}->{$model}->find(
	      'list', array('fields' => $attr['options']['fkfield'],
	      'recursive' => -1, 'conditions' => $conditions));
	  else
	    $list = $this->{$this->modelClass}->{$model}->find(
	      'list', array('fields' => $attr['options']['fkfield'],
	      'recursive' => -1, 'conditions' => $conditions));
	  if ($list)
	    Cache::write('keylist-'.$this->currentUser['User']['scope_id']."-".$attr['fktable'], $list, 'short');
	  else
	    $this->log(__('foreign-key lookup failed for ', true).
	      $attr['fktable'].'.'.$attr['options']['fkfield'].__(' in ').$model);
	}
        $dropDown[$field] = $list;

	// HasAndBelongsToMany - find existing selections in table identified by habtm
        if (isset($attr['habtm']) && isset($this->data['workObject']['id'])) {
	  $model = $this->{$this->modelClass}->modelFromTable($attr['habtm']);
#	  $field  = $attr['options']['fkfield'][0];

	  $dropDown[$field.'_sel'] = array();
	  foreach ($this->data['workObject']['Records'][$this->{$this->modelClass}->modelFromTable($attr['habtm'])] as $item) {
	    //  work around Cake bug cited in IL-199
	    if (!isset($item['table_name']) || $item['table_name'] == $attr['fktable']) {
	      // yet more hackery IL-292
	      //  TBD make this robust
	      if (isset($item[$this->{$this->modelClass}->modelFromTable($attr['fktable'])]['id']))
	        $dropDown[$field.'_sel'][$item['id']] = $item[$this->{$this->modelClass}->modelFromTable($attr['fktable'])]['id'];
	      else
	        $dropDown[$field.'_sel'][$item['id']] = $item[strtolower($this->{$this->modelClass}->modelFromTable($attr['fktable'])).'_id'];
	    }
	  }

	  // TBD Need host_id==null condition for User::add/edit
        }
      }

      // Pick up enum choices for fields defined in DB as enum type

      else if (isset($attr['type']) && substr($attr['type'],0,4) == 'enum') {
        if (!$list = Cache::read('keylist-'.$this->currentUser['User']['scope_id']."-".$this->modelClass.'-'.$field)) {
	  $items = explode("','",substr($attr['type'],6,-2));
	  $list = array();
	  foreach ($items as $item)
	    $list[$item] = $item;
	  Cache::write('keylist-'.$this->currentUser['User']['scope_id']."-".$this->modelClass.'-'.$field, $list, 'short');
	}
        $dropDown[$field] = $list;
      }

      // Pick up choices for fields defined as select_one

      else if ($attr['field_type_id'] == FTYPE_SELECT_ONE) { // select_one (from OptList)
        if (isset($attr['options']['optvalues'])) {
	  $list = array();
	  foreach ($attr['options']['optvalues'] as $item)
	    $list[$item] = $item;
	  $dropDown[$field] = $list;
	}
	else {
	  if (!$opt_list_loaded) {
	    $this->loadModel('OptList');
	    $opt_list_loaded = true;
	  }        
	  $query = $this->OptList->find('list', array ('conditions' =>
	   array('table_name' => 'meta_fields', 'foreign_key' => $attr['meta_field_id'],
		 'scope_id' => $this->currentUser['User']['scope_id']),
	   'fields' => array ('list_item'),
	   'recursive' => -1));
	  if (!empty($query))
	    $dropDown[$field] = $query;
	}
      }
    }
    if (!empty($dropDown))
      $this->data['dropDown'] = $dropDown;
  }

//////////////////////////////////////////////////////////////////////////

  // Load internationalized labels from cache
  function _getI18nLabels () {
    if ($this->modelClass != 'I18nLabel' && $this->modelClass != 'CakeError') {

      if (!$i18nLabels = Cache::read('I18nLabel')) {
	$this->loadModel('I18nLabel');
        $i18nLabels = $this->I18nLabel->find('list', array('conditions' =>
           array('locale' => $this->locale, 'help_text !=' => ''),
	   	 'conditions' => array('locale' => $this->locale, 'translation !=' => ''),
	         'fields' => array('I18nLabel.msgid', 'I18nLabel.translation')));
	if ($i18nLabels)
	  Cache::write('I18nLabel', $i18nLabels, 'short');
      }
      return $i18nLabels;
    }
    return array();
  }
//////////////////////////////////////////////////////////////////////////

  // Load internationalized label help from cache
  function _getI18nLabelHelp () {
    if ($this->modelClass != 'I18nLabel' && $this->modelClass != 'CakeError') {
      if (!$i18nLabels = Cache::read('I18nLabelHelp')) {
	$this->loadModel('I18nLabel');
        $i18nLabels = $this->I18nLabel->find('list', array('conditions' =>
           array('locale' => $this->locale, 'help_text !=' => ''),
	         'fields' => array('I18nLabel.msgid', 'I18nLabel.help_text')));
	if ($i18nLabels)
	  Cache::write('I18nLabelHelp', $i18nLabels, 'short');
      }
      return $i18nLabels;
    }
    return array();
  }
//////////////////////////////////////////////////////////////////////////

  function _getComments ($scope, $id) {
    $model = $this->modelClass;
    if (empty($id) || !isset($this->{$model}->hasMany['Comment']))
      return null;
    if (!$comments = Cache::read("comments-$scope-$model-$id")) {
      $comments = $this->{$this->modelClass}->Comment->find('all',
       array ('conditions' => array (
          'foreign_key' => $id,
          'table_name' => $this->{$this->modelClass}->table
	 ),
         'recursive' => -1));
      if (!empty($comments))
        Cache::write("comments-$scope-$model-$id", $comments);
    }
    return $comments;
  }

//////////////////////////////////////////////////////////////////////////
  private function _getAuth($scope, $cakeAuth, $model) {

    if ($model == 'CakeError')
      return;

    // Cache the object as auth-{scope}-{user_name}-{model}
    $user_name = $cakeAuth['User']['user_name'];

    if (!$auth = Cache::read("auth-$scope-$user_name-$model")) {
      $auth['User'] = $cakeAuth;
      $auth['User']['Scope']['scope_name'] =  $this->Session->read('Scope.scope_name');
      $auth['User']['Browser'] = $this->Session->read('Browser');

      $Controllers = App::objects('controller');
      $appIndex = array_search('App', $Controllers);
      if ($appIndex !== false ) {
        unset($Controllers[$appIndex]);
      }

      // TBD 6/15/2011 - move/cache this logic in Session
      foreach ($Controllers as $mod) {
        $auth['Model'][$mod]['index'] = $this->Acl->check ($user_name, "controllers/$mod/index", '*');
      }
      $auth['Model']['Search']['quick'] = $this->Acl->check ($user_name, "controllers/Search/quick", '*');
      $auth['Model']['Users']['password'] = $this->Acl->check ($user_name, "controllers/Users/password", '*');
      $auth['Model']['MetaFields']['edit'] = $this->Acl->check ($user_name, "controllers/MetaFields/edit", '*');

      if ($this->modelClass == 'Comment')
        $standard_actions =  array('add', 'delete', 'edit', 'view');
      else if ($this->modelClass == 'PendingAction')
        $standard_actions = array('add', 'delete', 'edit', 'run', 'view');
      else
        $standard_actions = array('add', 'comment', 'delete', 'edit', 'view');
      if ($this->modelClass != 'Search') {
        foreach ($standard_actions as $action)
        $auth['Actions'][$action] =
          $this->Acl->check ($user_name,
          "controllers/".Inflector::pluralize($this->modelClass)."/$action", '*');
      }

      // Cancel permissions on un-scoped tables for non-privileged users
      if ($this->currentUser['User']['scope_id'] != 1 &&
        !isset($this->{$this->modelClass}->belongsTo['Scope'])) {
        $auth['Actions']['add'] =
        $auth['Actions']['delete'] =
        $auth['Actions']['edit'] = false;
      }

      Cache::write("auth-$scope-$user_name-$model", $auth);
      $auth['inCache'] = false;
    }
    else
      $auth['inCache'] = true;

    // Variables used in the top-level default.ctp page

    $this->set('auth', $auth);
    $this->set('isAuthed', $this->isAuthed);
    return ($auth);
  }
//////////////////////////////////////////////////////////////////////////

  // This function queries whether any sync actions are queued up.
  function _syncNeeded () {
    if (isset($this->currentUser['User']) && $this->modelClass != 'CakeError') {
      $query = $this->{$this->modelClass}->query ('SELECT COUNT(*) AS count FROM pending_actions WHERE scope_id='.$this->currentUser['User']['scope_id']);
      return ($query['0']['0']['count'] != 0);
    }
    return (false);
  }
}
?>
