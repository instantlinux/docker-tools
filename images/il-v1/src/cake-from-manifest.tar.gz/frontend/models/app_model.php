<?php
// $Id: app_model.php 233 2011-10-21 20:34:19Z richb $

// Functions
//  afterFind
//  beforeSave
//  getPrimaryField
//  modelFromTable
//  getWorkObject
//  delWorkObject
//  getXMLbrief
//  valMacaddr
//  valPathname
//  valFilename
//  valDomain
//  valLabel

class AppModel extends Model {
  var $actsAs = array('Containable');

  function afterFind($results) {
    foreach ($results as $key => $val) {
      // TBD 6/20/2011: this gets called twice (2nd time on its own results!) -- figure
      //    out why and make sure it doesn't screw up if length coincides with 32
      if (isset($val['Ipv6']) && !empty($val['Ipv6']['ipv6_address']) &&
          strlen($val['Ipv6']['ipv6_address']) == 32) {
	$query = $this->query("SELECT il_inet6_hextoa('".$val['Ipv6']['ipv6_address']."') AS 'result';");
	$results[$key]['Ipv6']['ipv6_address'] = $query[0][0]['result'];
      }
      else {
        if (isset($val['Subnet']) && !empty($val['Subnet']['network_ipv6']) &&
          strlen($val['Subnet']['network_ipv6']) == 32) {
	  $query = $this->query("SELECT il_inet6_hextoa('".$val['Subnet']['network_ipv6']."') AS 'result';");
	  $results[$key]['Subnet']['network_ipv6'] = $query[0][0]['result'];
        }
        if (isset($val['Subnet']) && !empty($val['Subnet']['gateway_ipv6']) &&
          strlen($val['Subnet']['gateway_ipv6']) == 32) {
	  $query = $this->query("SELECT il_inet6_hextoa('".$val['Subnet']['gateway_ipv6']."') AS 'result';");
	  $results[$key]['Subnet']['gateway_ipv6'] = $query[0][0]['result'];
        }
      }
    }
    return $results;
  }
  function beforeSave($options) {
    if (isset($this->data[$this->name]['ipv6_address'])) {
      $query = $this->query("SELECT il_inet6_atohex('".$this->data[$this->name]['ipv6_address']."') AS 'result';");
      $this->data[$this->name]['ipv6_address'] = $query[0][0]['result'];
    }    
    if (isset($this->data[$this->name]['network_ipv6'])) {
      $query = $this->query("SELECT il_inet6_atohex('".$this->data[$this->name]['network_ipv6']."') AS 'result';");
      $this->data[$this->name]['network_ipv6'] = $query[0][0]['result'];
    }    
    if (isset($this->data[$this->name]['gateway_ipv6'])) {
      $query = $this->query("SELECT il_inet6_atohex('".$this->data[$this->name]['gateway_ipv6']."') AS 'result';");
      $this->data[$this->name]['gateway_ipv6'] = $query[0][0]['result'];
    }    
    return true;
  }

//////////////////////////////////////////////////////////////////////////

  function getPrimaryField () {
    // TBD this is hard-coded, if possible it should come from the
    // table-column options
    $lookup_ary = array (
      'Aco'	 => 'alias',
      'Action'   => 'action_code',
      'Aro'	 => 'alias',
      'Distro'	 => 'os_name',
      'DistroRev' => 'distro_arch',
      'DnsRecord' => 'ns_name',
      'Domain'	 => 'domain',
      'Group'	 => 'group_name',
      'Host'     => 'hostname',
      'Hostfile' => 'file_name',
      'Ipv4'     => 'ip_address',
      'Ipv6'     => 'ipv6_address',
      'IsoImage' => 'iso_file_name',
      'License'	 => 'product_key',
      'Location' => 'codeloc',
      'ModelNum' => 'model_num',
      'ModuleFile' => 'file_name',
      'NetDevice'  => 'mac_address',
      'Package'  => 'package_name',
      'Repository' => 'repo_name',
      'RepoGroup' => 'repo_group',
      'ResourceSet' => 'set_name',
      'Setting'	 => 'parameter_name',
      'StaticPage' => 'page_name',
      'Subnet'   => 'network',
      'Swmodule' => 'module_name',
      'Template' => 'template_name',
      'User'	 => 'user_name',
      'Vendor'	 => 'vendor_name'
    );
  return isset($lookup_ary[$this->name]) ? $lookup_ary[$this->name] : null;
  }

  function modelFromTable ($table) {
    switch ($table) {
      case 'aros': return 'ArosLocal';
      case 'acos': return 'AcosLocal';
      default: return Inflector::classify($table);
    }
  }

//////////////////////////////////////////////////////////////////////////

  // Function to set up a cached work object.
  // Parameters:
  //  $id      Primary record id  (null if creating new, won't be cached)
  //  $record  Contents of record (null if not already fetched), with primary
  //           key equal to Model name
  // Returns:
  //  Variable with
  //    'Attrs'         - full attributes and values of primary object, including meta
  //       (Null if record not found)
  //    'Records'       - raw data from the database for this & related models
  //    'created', 'modified', 'creator' - if applicable/available
  //    'id'            - unique object ID
  //    'inCache'       - true if fetched from memcached
  //    'friendly_time' - creation timestamp expressed as delta from present
  //    'persistent'    - true if a built-in persistent object
  //    'primaryField'  - key field
  //    'tableName'     - name of data table
  //	'validate'	- validation rules in CakePHP format

  function getWorkObject ($scope, $id, $record) {

    // Cache the object as schema-{scope}-{model} if called with blank id
    // or as work-{scope}-{model}-{id} if called with id
    if ((empty($id) && !$object = Cache::read("schema-$scope-".$this->name)) ||
        (!empty($id) && !$object = Cache::read("work-$scope-".$this->name."-$id"))) {

      $field_options = array(
      // Keywords recognized in the options field
         'bool_style', // Style to use for true/false table lookup
         'fkfield',    // Field name to use in index/view displays for joined fktable
         'groupsep',   // Insert a group separator on edit display
         'habtm',      // Third table to use (along with fktable) for multi-select HasAndBelongsToMany
         'index_omit', // Omit from index display any records matching this array list
         'label',      // Label (in English prior to translation) to use on index/view/edit
         'length',     // Limit input length on edit
         'mandatory',  // If set, field length must be greater than zero
	 'optvalues',  // Option values for drop-down selection list
         'primary',    // Highlight/hyperlink this field on index
         'ro',         // Read-only (omit from edit)
         'rules',      // Validation rule parameters (as specified in Cake book section 4.1.4)
         'style',      // Can specify one of:  autocomplete
         'validate'    // One or more CakePHP built-in validation rules (see Cake book section 4.1.4),
                       //  or regexp format
      );

      if (!empty ($id) && empty($record)) {
        $recursive = 1;
        $contain = null;
    // TBD figure out where to store these fields
        switch ($this->name) {
          case 'Host': $recursive = 2;
            $contain = array();
	    $contain[] = 'DistroRev.Distro';
	    $contain[] = 'Group.group_name';
	    $contain[] = 'HostType.host_type';
	    $contain[] = 'ModelNum.model_num';
	    $contain[] = 'ModelNum.Vendor';
	    $contain[] = 'NetDevice';
	    $contain[] = 'NetDevice.Domain';
	    $contain[] = 'SetMember.table_name';
            break;
          case 'ResourceSet': $recursive = 2;
            $contain = array();
	    $contain[] = 'SetMember.Host';
	    $contain[] = 'SetBinding.Swmodule';
	    $contain[] = 'SetBinding.Action';
	    $contain[] = 'SetBinding.Repository';
            break;
        }
        $conditions = array($this->name.'.id' => $id);
	if (isset($this->{$this->name}->belongsTo['Scope']))
	  $conditions[$this->name.'.scope_id'] = $scope;
	if (!$record = $this->find('first', array(
          'conditions' => $conditions,
          'contain' => $contain, 'recursive' => $recursive)))
	  return null;
      }
      $query = $this->query ('SHOW FULL COLUMNS FROM '.$this->table.';');
      $object = array ();
      $object['Records'] = $record;
      $object['tableName'] = $this->table;
      $object['validate'] = array ();
      if ($id != null) {
        $object['id'] = $id;
	if (isset($record[$this->name]['persistent']))
	  $object['persistent'] = ($record[$this->name]['persistent'] == 1);
      }
      $bool_model_loaded = false;

      foreach ($query as $column) {
        $field = $column['COLUMNS']['Field'];
        if ($field == 'persistent')
	  $object['canPersist'] = true;
	$schema = $this->schema($field);
        if (!in_array($field, array ('created', 'creator', 'modified', 'friendly_time',
           'codeloc', 'lft', 'rght', 'id', 'scope_id', 'persistent', 'md5passwd',
           'htpasswd', 'id1passwd', 'id2apasswd', 'sha256passwd', 'sha512passwd'))) {
	  $object['Attrs'][$field]['length'] = $schema['length'];

	  if ($schema['default'] != null)
            $object['Attrs'][$field]['default_value'] = $schema['default'];

	  else if ($id == null && ($field == 'uid' || $field == 'gid')) {
	    // Adding a uid or gid field: set default value
	    $query = $this->query ('SELECT MAX('.$field.')
	        + 1 AS nextid FROM '.$this->table.';');
	    $object['Attrs'][$field]['default_value'] = $query[0][0]['nextid'];
	  }
          $object['Attrs'][$field]['type'] = $schema['type'];
          if (strpos($field, 'passwd') !== false)
	    $object['Attrs'][$field]['field_type_id'] = FTYPE_PASSWORD;
	  elseif ($object['Attrs'][$field]['type'] == 'timestamp')
	      $object['Attrs'][$field]['field_type_id'] = 12; // timestamp
	  elseif (strpos($object['Attrs'][$field]['type'], 'enum') !== false)
	      $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_ONE;
	  elseif (strpos($object['Attrs'][$field]['type'], 'boolean') !== false)
	      $object['Attrs'][$field]['field_type_id'] = FTYPE_BOOLEAN;
	  elseif (strpos($object['Attrs'][$field]['type'], 'tinyint') !== false)
	      $object['Attrs'][$field]['field_type_id'] = FTYPE_BOOLEAN;
	  elseif (strpos($object['Attrs'][$field]['type'], 'int') !== false)
	      $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  else
	      $object['Attrs'][$field]['field_type_id'] = FTYPE_STRING;

          // Fill in the value
          if (!empty($record))
            $object['Attrs'][$field]['data_value'] = $record[$this->name][$field];

	  // For foreign-key fields, find the name of the foreign table
	  if ($field == 'parent_id') {
	    $object['Attrs'][$field]['fktable'] = $this->table;
	    $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_ONE;
	  }	    

	  // TBD make this more generic so it's not quite so MySQL-centric
	  // TBD more immediate:  fix the case for distro_rev_id=>distro_id in iso_images
	  else if (substr($field, -3, 3) == '_id' && $column['COLUMNS']['Key'] != '') {
	    $ds = ConnectionManager::getDataSource($this->useDbConfig);
            $query = $this->query ('SELECT REFERENCED_TABLE_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE CONSTRAINT_SCHEMA="'.$ds->config['database'].'" AND TABLE_NAME="'.
                     $this->table.'" AND REFERENCED_COLUMN_NAME IS NOT NULL AND COLUMN_NAME="'.$field.'";');
	    $object['Attrs'][$field]['fktable'] = $query[0]['KEY_COLUMN_USAGE']['REFERENCED_TABLE_NAME'];
	    $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_ONE;
	  }

	  // Parse the column comments for other options
	  $object['Attrs'][$field]['options'] = il_opt_parse($field_options, $column['COLUMNS']['Comment']);
        }

	// Special case for Meta / SoftMeta data_value field
	if (($this->name == 'Meta' || $this->name == 'SoftMeta') && $field == 'data_value') {
	  if (isset($object['Records']['MetaField']['length']))
	    $object['Attrs'][$field]['length'] = $object['Records']['MetaField']['length'];
	  $object['Attrs'][$field]['display_seq'] = $object['Records']['MetaField']['display_seq'];
	  $object['Attrs'][$field]['field_type_id'] = $object['Records']['MetaField']['field_type_id'];	 
	  $object['Attrs'][$field]['options'] = 
	    il_opt_parse($field_options, $object['Records']['MetaField']['options']);

	  if (isset($object['Attrs'][$field]['options']['length']))
	    $object['Attrs'][$field]['length'] = $object['Attrs'][$field]['options']['length'][0];

	  // If field is boolean, lookup up true/false value and override data_value

	  if ($object['Attrs'][$field]['field_type_id'] == FTYPE_BOOLEAN) {
	    if (!$bool_model_loaded) {
	      $this->bindModel(array('hasMany' => array('BooleanValue')));
	      $bool_model_loaded = true;
	    }
	    $boolquery = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('OR' => array ('true' => $object['Attrs'][$field]['data_value'],
		    'false' => $object['Attrs'][$field]['data_value'])), 'recursive' => -1));
	    if (!empty($boolquery)) {
	      $object['Attrs'][$field]['bool_style'] = $boolquery['BooleanValue']['bool_style'];
	      $object['Attrs'][$field]['data_value'] =
	    			$object['Attrs'][$field]['data_value'] == $boolquery['BooleanValue']['true'];
	    }
	  }
	}

	//////////////
	// BEGIN Extra fields not in the table definition

	// TBD figure out where to define these
	if ($this->name == 'User' && $field == 'passwd') {
	  $field = 'secondary_groups';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'users_groups';
	  $object['Attrs'][$field]['fktable'] = 'groups';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('group_name'), 'label' => array('secondary_groups'));
	  $object['Attrs'][$field]['groupsep'] = true;
	}
	if ($this->name == 'DistroRev' && $field == 'distro_id') {
	  $field = 'num_bits';
	  $object['Attrs'][$field]['length'] = 10;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['options'] = array ('ro' => '1');
	}
        else if ($this->name == 'Host') {
         if ($field == 'hostname') {
	  $field = 'domain_id';
	  $object['Attrs'][$field]['length'] = 10;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'net_devices';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('domain'));
	 }
         else if ($field == 'model_num_id') {
	  $field = 'vendor_name';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'model_nums';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('vendor_name'), 'ro' => '1');
	 }
         else if ($field == 'host_type_id') {
	  $field = 'distro';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'distro_revs';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('distro'), 'ro' => true);
	  $field = 'num_bits';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'distro_revs';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('num_bits'), 'ro' => true);
         }
	 else if ($field == 'group_id') {
	  $field = 'resource_sets';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_members';
	  $object['Attrs'][$field]['fktable'] = 'resource_sets';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('set_name'), 'label' => array('sets'));
	  $field = 'module_bindings';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_bindings';
	  // TBD: this doesn't really work, we override it in hosts_controller
	  // for now
	  // $object['Attrs'][$field]['fktable'] = 'resource_sets';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('module_name'), 'label' => array('module_bindings'));
	 }
	}
	else if ($this->name == 'ResourceSet' && $field == 'set_name') {
	  // TBD IL-199 this is hardwired to hosts/swmodules, make more generic
	  $field = 'set_members';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_members';
	  $object['Attrs'][$field]['fktable'] = 'hosts';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('hostname'), 'label' => array('set_members'));
	  $field = 'module_bindings';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_bindings';
	  $object['Attrs'][$field]['fktable'] = 'swmodules';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('module_name'), 'label' => array('module_bindings'));
	  $field = 'repository_bindings';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_bindings';
	  $object['Attrs'][$field]['fktable'] = 'repositories';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('repo_name'), 'label' => array('repository_bindings'));
	  $field = 'action_bindings';
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_SELECT_MULTI;
	  $object['Attrs'][$field]['habtm'] = 'set_bindings';
	  $object['Attrs'][$field]['fktable'] = 'actions';
	  $object['Attrs'][$field]['options'] = array ('fkfield' =>
	    array('action_code'), 'label' => array('action_bindings'));
	}
	else if ($this->name == 'NetDevice' && $field == 'domain_id') {
	  $field = 'ip_address';
	  $object['Attrs'][$field]['virtual'] = true;
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'ipv4s';
	  $object['Attrs'][$field]['options'] = array ('fkfield' => array('ip_address'));
	  $object['Attrs'][$field]['data_value'] = isset($object['Records']['Ipv4']['id']) ?
	     $object['Records']['Ipv4']['id'] : null;

	  $field = 'ipv6_address';
	  $object['Attrs'][$field]['virtual'] = true;
	  $object['Attrs'][$field]['length'] = 0;
	  $object['Attrs'][$field]['field_type_id'] = FTYPE_INTEGER;
	  $object['Attrs'][$field]['fktable'] = 'ipv6s';
	  $object['Attrs'][$field]['options'] = array ('fkfield' => array('ipv6_address'));
	  $object['Attrs'][$field]['data_value'] = isset($object['Records']['Ipv6']['id']) ?
	     $object['Records']['Ipv6']['id'] : null;
	}
	// END extra fields not in table definition
	///////////////////
      }

      if (isset($this->hasMany['Meta']) && $this->name != 'Swmodule') {
        $meta = array();
        $params = $this->Meta->MetaField->find('all', array(
          'conditions' =>
            array('MetaField.table_name' => $this->table,
	          'MetaField.scope_id' => $scope),
          'recursive' => -1));
        foreach ($params as $key => $item) {
          $field = $item['MetaField']['parameter_name'];
          if ($item['MetaField']['default_value'] != null)
	    $object['Attrs'][$field]['default_value'] = $item['MetaField']['default_value'];

	  // If field type is boolean, determine bool_style
	  if ($item['MetaField']['field_type_id'] == FTYPE_BOOLEAN) {
	    if (!$bool_model_loaded) {
		    $this->bindModel(array('hasMany' => array('BooleanValue')));
		    $bool_model_loaded = true;
	    }
	    $boolquery = $this->BooleanValue->find('first', array ('conditions' =>
		    array ('OR' => array ('true' => $item['MetaField']['default_value'],
		    'false' => $item['MetaField']['default_value'])), 'recursive' => -1));
	    if (!empty($boolquery)) {
	      $object['Attrs'][$field]['bool_style'] = $boolquery['BooleanValue']['bool_style'];
	      $object['Attrs'][$field]['default_value'] =
	    			$item['MetaField']['default_value'] == $boolquery['BooleanValue']['true'];
	    }
	  }

          $query = $this->Meta->find('first', array(
            'conditions' =>
              array('Meta.meta_field_id' => $item['MetaField']['id'],
	            'Meta.foreign_key' => $id,
		    'Meta.table_name' => $this->table),
            'recursive' => -1));

          if (!empty($query)) {
            $object['Attrs'][$field]['meta_id'] = $query['Meta']['id'];

	    // Special treatment for boolean fields -- translate into true or false

	    if ($item['MetaField']['field_type_id'] == FTYPE_BOOLEAN &&
	        isset($object['Attrs'][$field]['bool_style']))
	      $object['Attrs'][$field]['data_value'] =
	    			$query['Meta']['data_value'] == $boolquery['BooleanValue']['true'];
	    else
              $object['Attrs'][$field]['data_value'] = $query['Meta']['data_value'];
          }

	  $fieldLengthByTypes = array(0, 11, 0, 17, 25, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0, 0);
	  if (isset($fieldLengthByTypes[$item['MetaField']['field_type_id']]))
	    $object['Attrs'][$field]['length'] = 
	      $fieldLengthByTypes[$item['MetaField']['field_type_id']];
	  else
	    $object['Attrs'][$field]['length'] = 0;

          $object['Attrs'][$field]['field_type_id'] = $item['MetaField']['field_type_id'];
          $object['Attrs'][$field]['meta_field_id'] = $item['MetaField']['id'];
	  $object['Attrs'][$field]['groupsep'] = false;

	  // Pick up field options
	  $object['Attrs'][$field]['options'] = 
	    il_opt_parse($field_options, $item['MetaField']['options']);

	  if (isset($object['Attrs'][$field]['options']['length']))
	    $object['Attrs'][$field]['length'] = $object['Attrs'][$field]['options']['length'][0];
        }
      }

      // Look for validation rules, primaryField, autoComplete
      foreach ($object['Attrs'] as $field => $attr) {
        if (isset($attr['options']['mandatory']))
	  $object['Attrs'][$field]['mandatory'] = true;
        if (isset($attr['options']['validate'])) {
	    $val_entry = array();
	    if (isset($object['Attrs'][$field]['options']['rules']))
	      switch ($object['Attrs'][$field]['options']['validate'][0]) {
	        case 'cc':
	        case 'extension':
	        case 'inList':
	        case 'multiple':
		  // Rules are appended as a sub-array
	          $object['Attrs'][$field]['options']['validate'][] =
	            $object['Attrs'][$field]['options']['rules'];
	          $val_entry['rule'] = $object['Attrs'][$field]['options']['validate'];
		  break;
		default:
		  // Rules are tacked on as separate elements onto the array
	          $val_entry['rule'] = array_merge(
	            $object['Attrs'][$field]['options']['validate'],
	            $object['Attrs'][$field]['options']['rules']);
	      }
	    else
	      $val_entry['rule'] = $object['Attrs'][$field]['options']['validate'][0];
	    if (!isset($object['Attrs'][$field]['mandatory']) ||
	        $object['Attrs'][$field]['mandatory'] == false)
	      $val_entry['allowEmpty'] = true;
	    $object['validate'][$field] = $val_entry;
        }
	if (isset($attr['options']['primary']))
	  $object['primaryField'] = $field;

	// Enable autocomplete Ajax logic if needed
	if (isset($object['Attrs'][$field]['options']['style']) &&
	            $object['Attrs'][$field]['options']['style'][0] == 'autocomplete')
	  $object['enableAutocomplete'] = true;
      }

      // Pick one of the columns as the primary field, if not already found
      if (!isset($object['primaryField'])) {
        $fields = array_keys($object['Attrs']);
        $object['primaryField'] = $fields[0];
      }
      if (empty($object['validate']))
        unset($object['validate']);

      // Record-creation info: translate 'created' field to 'friendly_time'
      if (isset($record[$this->name]['created'])) {
       $friendly_time = $this->query("SELECT get_timestamp_diff('".$record[$this->name]['created']."') AS friendly_time;");

        $object['created'] = $record[$this->name]['created'];
        $object['creator'] = $record[$this->name]['creator'];
        if (isset($record[$this->name]['modified']))
	  $object['modified'] = $record[$this->name]['modified'];
        $object['friendly_time'] = $friendly_time['0']['0']['friendly_time'];
      }

      if (isset($object['Attrs']['location_id'])) {
        if ((isset($object['Attrs']['parent_id']['data_value']) && $object['Attrs']['parent_id']['data_value'] == null) ||
            !empty($object['Attrs']['location_id']['data_value']))
          $object['location_path'] = $this->Location->getpath($object['Attrs']['location_id']['data_value']);
        else if (isset($object['Attrs']['parent_id']['data_value'])) {
	  $query = $this->find('first', array('conditions' =>
            array($this->name.'.id' => $object['Attrs']['parent_id']['data_value']),
            'recursive' => -1, 'fields' => array('location_id')));
          $object['location_path'] = $this->Location->
            getpath($query[$this->name]['location_id']);
	}
      }

      if (!empty($id)) 
        Cache::write("work-$scope-".$this->name."-$id", $object, 'short');
      else
        Cache::write("schema-$scope-".$this->name, $object, 'short');
      $object['inCache'] = false;
    }
    else
      $object['inCache'] = true;

    return $object;
  }

//////////////////////////////////////////////////////////////////////////

  function delWorkObject ($scope, $id, $model = null) {
    if ($model == null)
      $model = $this->name;

//$this->log("delwork($id): "."work-$scope-$model-$id");
    Cache::delete("work-$scope-$model-$id");
    Cache::delete("schema-$scope-$model");
# TBD why doesn't the view cache get cleared (ResourceSet::edit)??!? 5/11/2011
    Cache::delete("view-$scope-$model-$id");
    Cache::delete("comment-$scope-$model-$id");
    Cache::delete("keylist-$scope-".$this->table);
    if ($model == 'I18nLabel')
      Cache::delete("i18nLabelHelp-$scope");
  }

//////////////////////////////////////////////////////////////////////////

  function getXMLbrief ($scope, $currentUser, $workObject, $conditions = null,
     $id = null, $details = false, $related = false) {
    $field_list = array();
    $field_exclude = array ('lft', 'rght', 'scope_id', 'persistent', 'md5passwd',
           'htpasswd', 'id1passwd', 'id2apasswd', 'sha256passwd', 'sha512passwd');
    if (!$details) {
      $field_exclude[] = 'id';
      $field_exclude[] = 'created';
      $field_exclude[] = 'creator';
      $field_exclude[] = 'modified';
    }
    $join_list = array();
    $query = $this->query ('SHOW FULL COLUMNS FROM '.$this->table.';');
    foreach ($query as $column) {
      $field = $column['COLUMNS']['Field'];

      // Fill in the value (unless restricted) for XML reendering
      if (!in_array($field, $field_exclude) &&
      	  (in_array($field, array('id','created','creator','modified')) ||
	   $currentUser['User']['user_name'] == 'ilclient' ||
	      ($workObject['Attrs'][$field]['field_type_id'] != FTYPE_PASSWORD &&
	       $workObject['Attrs'][$field]['field_type_id'] != FTYPE_RESTRICTED &&
	       $workObject['Attrs'][$field]['field_type_id'] != FTYPE_ARRAY_RESTRICTED))) {

	if ($field == 'new_value' || $field == 'previous_value') {
	  $field_list[] = "IF({$this->name}.field_type_id NOT IN(10,13,14),{$this->name}.$field,'') AS $field";
	}
        elseif ($field != 'parent_id' && isset($workObject['Attrs'][$field]['field_type_id'])) {
	  switch ($workObject['Attrs'][$field]['field_type_id']) {
	    case FTYPE_SELECT_ONE:
	      if (isset($workObject['Attrs'][$field]['fktable'])) {
	        $fkmodel = Inflector::classify($workObject['Attrs'][$field]['fktable']);
	        $fkfield = $workObject['Attrs'][$field]['options']['fkfield'][0];
		$fq_field = "$fkmodel.$fkfield";

	        if ($this->{$this->modelFromTable($workObject['Attrs'][$field]['fktable'])}->isVirtualField($fkfield))
	        {
		  # See CakePHP 1.3 book section 3.7.10.4
	          $this->virtualFields[$fkfield] =
		     $this->{$fkmodel}->virtualFields[$fkfield];
	     	  $fq_field = $fkfield;
		}	        
	        $field_list[] = $fq_field;
	        $join_list[] = array('table' => $workObject['Attrs'][$field]['fktable'],
		    'alias' => $fkmodel, 'type' => 'left', 'conditions' =>
		     array("$fkmodel.id={$this->name}.$field"));
	      }
	      else
	        $field_list[] = $this->name.'.'.$field;
	      break;
	    default:
	      $field_list[] = $this->name.'.'.$field;
	  }
	}
	else
	  $field_list[] = $this->name.'.'.$field;
      }
    }

    // Pick up meta
    $meta_seen = false;
    foreach ($workObject['Attrs'] as $field => $attr) {
      if (isset($attr['meta_field_id']) &&
          $attr['field_type_id'] != FTYPE_PASSWORD &&
          $attr['field_type_id'] != FTYPE_RESTRICTED &&
          $attr['field_type_id'] != FTYPE_ARRAY_RESTRICTED) {
	$meta_seen = true;
        $field_list[] = "(SELECT data_value FROM meta JOIN meta_fields ON meta_fields.id=meta.meta_field_id
 WHERE meta.table_name='{$workObject['tableName']}' AND meta.foreign_key={$this->name}.id
 AND parameter_name='$field') AS $field";
      }
    }
    $conditions[$this->name.'.scope_id'] = $scope;
    if ($id != null)
      $conditions[$this->name.'.id'] = $id;

    // Clobber the 'related' URL parameter.  TBD:  fix it so it doesn't fail with
    //   Warning (512): SQL Error: 1066: Not unique table/alias
    $related = false;

    $query = $this->find('all', array ('conditions' => $conditions,
        'fields' => $field_list, 'joins' => $join_list, 'recursive' => $related ? 0 : -1));
    if ($meta_seen)
      foreach ($query as $key => $record) {
        $query[$key][$this->name] += $record[0];
	unset($query[$key][0]);
      }
    return ($query);
  }

//////////////////////////////////////////////////////////////////////////

# function find($type, $options = array()) {
#  if (!isset($options['conditions']['Permission.aro_id']))
#    $this->log ('find: '.print_r($options, true));

#    return parent::find($type, $options);
#  }
  function valMacaddr ($check) {
    foreach ($check as $item) {
      if (!preg_match('/^[0-9a-fA-F]{2}(?=([:.-]?))(?:\\1[0-9a-fA-F]{2}){5}$/', $item))
        return false;
    }
    return true;
  }
  function valPathname ($check) {
    foreach ($check as $item) {
      if (!preg_match('/^\/[0-9a-z \.\/~@#%^_+=:;\[\]()]/i', $item))
        return false;
    }
    return true;
  }
  function valFilename ($check) {
    foreach ($check as $item) {
      if (!preg_match('/^[0-9a-z \.~@#%^_+=:;\[\]()]/i', $item))
        return false;
    }
    return true;
  }
  function valDomain ($check) {
    foreach ($check as $item) {
      if (!preg_match('/^[a-z0-9-.]+$/', $item))
        return false;
    }
    return true;
  }
  function valLabel ($check) {
    foreach ($check as $item) {
      if (!preg_match('/^[a-z0-9.+_-]+$/', $item))
        return false;
    }
    return true;
  }
}
?>
