<?php
/**
 * $Id: aro.php 156 2011-06-29 17:54:14Z richb $
 *  This is a replacement for the CakePHP Aro class

 * Access Request Object
 *
 * @package       cake
 * @subpackage    cake.cake.libs.model
 */
class Aro extends AclNode {

/**
 * Model name
 *
 * @var string
 * @access public
 */
	var $name = 'Aro';

/**
 * AROs are linked to ACOs by means of Permission
 *
 * @var array
 * @access public
 */
	var $hasAndBelongsToMany = array('Aco' => array('with' => 'Permission'));

	// Add scope_id
        function save($data = null, $validate = true, $fieldList = array()) {
                 $data['scope_id'] = $this->currentUser['User']['scope_id'];
//                 $this->log("AclNode::save: ".print_r($data,true));
                 return parent::save($data, $validate, $fieldList);
        }
}
