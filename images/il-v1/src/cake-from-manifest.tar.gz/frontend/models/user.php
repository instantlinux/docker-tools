<?php
// $Id: user.php 214 2011-09-14 21:00:01Z richb $ //

class User extends AppModel {
  var $name = 'User';
  var $order = array ('User.user_name');
  var $hasMany = array ('Hostfile', 'Action', 'Mirror', 'UsersGroup',
    'UserOverride',
    'Comment' => array('conditions' => array('Comment.table_name = "users"'),
     'foreignKey' => 'foreign_key'),
     'History' => array('conditions' => array('History.table_name="users"'),
       'foreignKey' => 'foreign_key'), 
    'Meta' => array('conditions' => array('Meta.table_name = "users"'),
     'foreignKey' => 'foreign_key'));
  var $belongsTo = array ('Group', 'Scope');
  var $actsAs = array('Acl' => array('type' => 'requester'));

  function parentNode() {
    if (!$this->id && empty($this->data)) {
        return null;
    }
    if (isset($this->data['User']['group_id'])) {
    $groupId = $this->data['User']['group_id'];
    } else {
      $groupId = $this->field('group_id');
    }
    if (!$groupId) {
    return null;
    } else {
        return array('Group' => array('id' => $groupId));
    }
  }

#    function hashPasswords($data) {
#         $data['User']['pass'] = crypt($data['User']['passwd'], substr($data['User']['user_name'], 0, 2));
#         return $data;
#    }
  function hashPasswords($data) {
       if (isset($data['User']['md5passwd'])) {
         $data['User']['md5passwd'] = md5($data['User']['md5passwd']);
         return $data;
       }
       return $data;
  }
  function beforeSave() {

       $query = $this->query ('SELECT data_value FROM settings WHERE scope_id='.$this->currentUser['User']['scope_id'].' AND parameter_name="password_salt"');
       if (isset($query[0]['settings']['data_value']))
         $salt = $query[0]['settings']['data_value'];
       if (empty($salt)) $salt = '10RT7e25';

       // If passwd is set, generate strings for passwd plus any other related fields

       if (!empty($this->data['User']['passwd'])) {

         // For md5 we don't use salt
         $this->data['User']['md5passwd'] = md5($this->data['User']['passwd']);

         // Use crypt to generate the others
         $this->data['User']['id1passwd'] = crypt($this->data['User']['passwd'], '$1$'.substr($salt,0,8));
         $this->data['User']['id2apasswd'] =
               crypt($this->data['User']['passwd'], '$2a$10$'.substr(md5(uniqid(rand(), true)),0,22));
         $this->data['User']['htpasswd'] = 
               crypt($this->data['User']['passwd'], '$2a$'.substr($this->data['User']['user_name'], 0, 2));
         $this->data['User']['sha256passwd'] = crypt($this->data['User']['passwd'], '$5$'.substr($salt,0,2));
         $this->data['User']['sha512passwd'] = crypt($this->data['User']['passwd'], '$6$'.substr($salt,0,16));

	 // !!This one has to be last!!  *Think* about it.
	 $this->data['User']['passwd'] = $this->data['User']['sha256passwd'];
       }
       else {
         // avoid overwriting empty values
	 unset($this->data['User']['md5passwd']);
         unset($this->data['User']['htpasswd']);
         unset($this->data['User']['passwd']);
         unset($this->data['User']['id1passwd']);
         unset($this->data['User']['id2apasswd']);
         unset($this->data['User']['sha256passwd']);
         unset($this->data['User']['sha512passwd']);
       }
       return true;
  }

  function afterSave($created) {
    if (isset($this->currentUser) && $created) {
      $this->query("CALL queue_action('upd_security','".$this->currentUser['User']['user_name']."',".$this->currentUser['User']['scope_id'].",NULL);");
      $this->query("CALL acl_set_aliases(".$this->currentUser['User']['scope_id'].");");
    }
  }    
  function afterDelete() {
      $this->query("CALL queue_action('upd_security','".$this->currentUser['User']['user_name']."',".$this->currentUser['User']['scope_id'].",NULL);");
  }    
}
?>
